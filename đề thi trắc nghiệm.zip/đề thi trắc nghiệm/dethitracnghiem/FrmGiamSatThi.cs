using System;
using System.Drawing;
using System.Windows.Forms;

namespace dethitracnghiem
{
    public partial class FrmGiamSatThi : Form
    {
        public FrmGiamSatThi()
        {
            InitializeComponent();
        }

        private void FrmGiamSatThi_Load(object sender, EventArgs e)
        {
            NapDanhSachGiamSat();
        }

        private void NapDanhSachGiamSat()
        {
            dgvGiamSat.Rows.Clear();
            foreach (var kq in DataStore.DanhSachKetQua)
            {
                int rowIndex = dgvGiamSat.Rows.Add(
                    kq.MSSV,
                    kq.HoTen,
                    kq.TenMon,
                    kq.Diem.ToString("0.0"),
                    kq.XepLoai,
                    kq.ThoiGian.ToString("dd/MM/yyyy HH:mm:ss"),
                    "Đã hoàn thành"
                );

                dgvGiamSat.Rows[rowIndex].Cells["colTrangThai"].Style.ForeColor = Color.Green;
                dgvGiamSat.Rows[rowIndex].Cells["colTrangThai"].Style.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            NapDanhSachGiamSat();
        }
    }
}

