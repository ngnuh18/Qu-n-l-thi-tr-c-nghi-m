using System;
using System.Windows.Forms;

namespace dethitracnghiem
{
    public partial class FrmDangKy : Form
    {
        public string TenDangNhapMoi { get; private set; } = "";
        public string MatKhauMoi { get; private set; } = "";

        public FrmDangKy()
        {
            InitializeComponent();
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            string user = txtTenDangNhap.Text.Trim();
            string pass = txtMatKhau.Text;
            string xacNhan = txtXacNhan.Text;
            string mssv = txtMSSV.Text.Trim();
            string hoTen = txtHoTen.Text.Trim();
            string lop = txtLop.Text.Trim();

            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass))
            {
                MessageBox.Show("Vui lòng nhập tên đăng nhập và mật khẩu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTenDangNhap.Focus();
                return;
            }

            if (pass != xacNhan)
            {
                MessageBox.Show("Mật khẩu xác nhận không khớp!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtXacNhan.Clear();
                txtXacNhan.Focus();
                return;
            }

            if (string.IsNullOrEmpty(mssv) || string.IsNullOrEmpty(hoTen))
            {
                MessageBox.Show("Vui lòng nhập mã số sinh viên và họ tên!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMSSV.Focus();
                return;
            }

            string err;
            if (DataStore.DangKySinhVien(user, pass, mssv, hoTen, lop, out err))
            {
                TenDangNhapMoi = user;
                MatKhauMoi = pass;
                MessageBox.Show("Đăng ký tài khoản sinh viên thành công!\nBạn có thể đăng nhập ngay.", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show(err, "Lỗi đăng ký", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}

