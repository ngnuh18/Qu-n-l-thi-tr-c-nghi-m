using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace dethitracnghiem
{
    public partial class FrmKetQua : Form
    {
        private KetQuaThi ketQuaHienTai;

        public FrmKetQua()
        {
            InitializeComponent();
            this.pnlBieuDo.Paint += PnlBieuDo_Paint;
            this.pnlChuThich.Paint += PnlChuThich_Paint;
        }

        public FrmKetQua(KetQuaThi kq) : this()
        {
            ketQuaHienTai = kq;
        }

        private void FrmKetQua_Load(object sender, EventArgs e)
        {
            if (ketQuaHienTai == null)
            {
                ketQuaHienTai = DataStore.KetQuaMoiNhat;
            }

            if (ketQuaHienTai != null)
            {
                lblHoTenVal.Text = ketQuaHienTai.HoTen;
                lblMonThiVal.Text = ketQuaHienTai.TenMon;
                lblDiemVal.Text = ketQuaHienTai.Diem.ToString("0.0");
                lblXepLoaiVal.Text = ketQuaHienTai.XepLoai;
            }
            else
            {
                lblHoTenVal.Text = !string.IsNullOrEmpty(DataStore.HoTenHienTai) ? DataStore.HoTenHienTai : "Chưa có";
                lblMonThiVal.Text = "Chưa có bài thi";
                lblDiemVal.Text = "---";
                lblXepLoaiVal.Text = "Chưa thi";
            }

            pnlBieuDo.Invalidate();
            pnlChuThich.Invalidate();
        }

        private void PnlBieuDo_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Kích thước biểu đồ tròn
            int size = Math.Min(pnlBieuDo.Width, pnlBieuDo.Height) - 20;
            int x = (pnlBieuDo.Width - size) / 2;
            int y = (pnlBieuDo.Height - size) / 2;
            Rectangle rect = new Rectangle(x, y, size, size);

            // Tỉ lệ theo hình ảnh mẫu: Giỏi 60%, Khá 30%, Trung bình 10%
            float tyLeGioi = 60f;
            float tyLeKha = 30f;
            float tyLeTB = 10f;

            float sweepGioi = (tyLeGioi / 100f) * 360f;
            float sweepKha = (tyLeKha / 100f) * 360f;
            float sweepTB = (tyLeTB / 100f) * 360f;

            Color colGioi = Color.FromArgb(204, 60, 115);    // Đỏ hồng đậm
            Color colKha = Color.FromArgb(246, 150, 175);    // Hồng đào
            Color colTB = Color.FromArgb(250, 200, 215);     // Hồng nhạt

            using (SolidBrush bGioi = new SolidBrush(colGioi))
            using (SolidBrush bKha = new SolidBrush(colKha))
            using (SolidBrush bTB = new SolidBrush(colTB))
            using (Pen borderPen = new Pen(Color.White, 2f))
            {
                float startAngle = 0f;

                // 1. Giỏi
                g.FillPie(bGioi, rect, startAngle, sweepGioi);
                g.DrawPie(borderPen, rect, startAngle, sweepGioi);
                startAngle += sweepGioi;

                // 2. Khá
                g.FillPie(bKha, rect, startAngle, sweepKha);
                g.DrawPie(borderPen, rect, startAngle, sweepKha);
                startAngle += sweepKha;

                // 3. Trung bình
                g.FillPie(bTB, rect, startAngle, sweepTB);
                g.DrawPie(borderPen, rect, startAngle, sweepTB);
            }
        }

        private void PnlChuThich_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            Color colGioi = Color.FromArgb(204, 60, 115);
            Color colKha = Color.FromArgb(246, 150, 175);
            Color colTB = Color.FromArgb(250, 200, 215);

            using (Font f = new Font("Segoe UI", 10f, FontStyle.Regular))
            using (Brush textBrush = new SolidBrush(Color.FromArgb(70, 70, 70)))
            using (Brush bGioi = new SolidBrush(colGioi))
            using (Brush bKha = new SolidBrush(colKha))
            using (Brush bTB = new SolidBrush(colTB))
            {
                int boxSize = 14;
                int startY = 30;
                int lineGap = 42;

                // Giỏi 60%
                g.FillRectangle(bGioi, 10, startY, boxSize, boxSize);
                g.DrawString("Giỏi   60%", f, textBrush, 32, startY - 2);

                // Khá 30%
                g.FillRectangle(bKha, 10, startY + lineGap, boxSize, boxSize);
                g.DrawString("Khá   30%", f, textBrush, 32, startY + lineGap - 2);

                // Trung bình 10%
                g.FillRectangle(bTB, 10, startY + lineGap * 2, boxSize, boxSize);
                g.DrawString("Trung bình 10%", f, textBrush, 32, startY + lineGap * 2 - 2);
            }
        }

        private void btnXemChiTiet_Click(object sender, EventArgs e)
        {
            if (ketQuaHienTai == null)
            {
                MessageBox.Show("Chưa có thông tin bài thi để xem chi tiết!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Mở hộp thoại chi tiết bài thi
            Form frmDetail = new Form();
            frmDetail.Text = "Chi tiết kết quả bài thi - " + ketQuaHienTai.TenMon;
            frmDetail.Size = new Size(720, 500);
            frmDetail.StartPosition = FormStartPosition.CenterParent;
            frmDetail.BackColor = Color.FromArgb(255, 235, 245);

            Label lblSum = new Label();
            lblSum.Dock = DockStyle.Top;
            lblSum.Height = 45;
            lblSum.Font = new Font("Segoe UI", 11f, FontStyle.Bold);
            lblSum.ForeColor = Color.FromArgb(170, 30, 85);
            lblSum.TextAlign = ContentAlignment.MiddleCenter;
            lblSum.Text = string.Format("Học viên: {0} | Môn: {1} | Điểm: {2:0.0} | Đúng: {3}/{4}",
                ketQuaHienTai.HoTen, ketQuaHienTai.TenMon, ketQuaHienTai.Diem, ketQuaHienTai.SoCauDung, ketQuaHienTai.TongSoCau);

            DataGridView dgv = new DataGridView();
            dgv.Dock = DockStyle.Fill;
            dgv.ReadOnly = true;
            dgv.AllowUserToAddRows = false;
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.BackgroundColor = Color.White;
            dgv.RowHeadersVisible = false;

            dgv.Columns.Add("STT", "Câu");
            dgv.Columns.Add("NoiDung", "Nội dung câu hỏi");
            dgv.Columns.Add("Chon", "Đã chọn");
            dgv.Columns.Add("Dung", "Đáp án đúng");
            dgv.Columns.Add("KetQua", "Kết quả");

            dgv.Columns["STT"].FillWeight = 15;
            dgv.Columns["NoiDung"].FillWeight = 55;
            dgv.Columns["Chon"].FillWeight = 15;
            dgv.Columns["Dung"].FillWeight = 15;
            dgv.Columns["KetQua"].FillWeight = 15;

            int index = 1;
            foreach (var item in ketQuaHienTai.ChiTiet)
            {
                string status = item.LaDung ? "✓ Đúng" : "✗ Sai";
                int rowIndex = dgv.Rows.Add(index++, item.CauHoi.NoiDung, item.DapAnChon, item.DapAnDung, status);
                if (item.LaDung)
                {
                    dgv.Rows[rowIndex].Cells["KetQua"].Style.ForeColor = Color.Green;
                    dgv.Rows[rowIndex].Cells["KetQua"].Style.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
                }
                else
                {
                    dgv.Rows[rowIndex].Cells["KetQua"].Style.ForeColor = Color.Red;
                    dgv.Rows[rowIndex].Cells["KetQua"].Style.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
                }
            }

            Button btnClose = new Button();
            btnClose.Text = "Đóng";
            btnClose.Dock = DockStyle.Bottom;
            btnClose.Height = 40;
            btnClose.BackColor = Color.FromArgb(255, 220, 235);
            btnClose.FlatStyle = FlatStyle.Flat;
            btnClose.Click += (s, ev) => frmDetail.Close();

            frmDetail.Controls.Add(dgv);
            frmDetail.Controls.Add(lblSum);
            frmDetail.Controls.Add(btnClose);
            frmDetail.ShowDialog(this);
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

