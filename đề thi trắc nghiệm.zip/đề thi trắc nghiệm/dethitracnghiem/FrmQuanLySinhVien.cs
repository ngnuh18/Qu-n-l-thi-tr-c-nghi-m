using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace dethitracnghiem
{
    public partial class FrmQuanLySinhVien : Form
    {
        private string vaiTro;

        public FrmQuanLySinhVien()
        {
            InitializeComponent();
            this.vaiTro = DataStore.VaiTroHienTai;

            btnTim.Click += btnTim_Click;
            btnThem.Click += btnThem_Click;
            btnSua.Click += btnSua_Click;
            btnXoa.Click += btnXoa_Click;
            btnNhapExcel.Click += btnNhapExcel_Click;
            txtTimKiem.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { btnTim_Click(s, e); e.SuppressKeyPress = true; } };
            this.Load += FrmQuanLySinhVien_Load;
        }

        public FrmQuanLySinhVien(string role) : this()
        {
            this.vaiTro = role;
        }

        private void FrmQuanLySinhVien_Load(object sender, EventArgs e)
        {
            ApDungPhanQuyen();
            HienThiDanhSach(DataStore.DanhSachSinhVien);
        }

        private void ApDungPhanQuyen()
        {
            if (vaiTro == "Sinh viên")
            {
                // Khi đăng nhập với vai trò sinh viên: không hiển thị nút thêm sửa xóa và nhập file
                btnThem.Visible = false;
                btnSua.Visible = false;
                btnXoa.Visible = false;
                btnNhapExcel.Visible = false;
            }
            else
            {
                // Quản trị viên có đầy đủ đặc quyền
                btnThem.Visible = true;
                btnSua.Visible = true;
                btnXoa.Visible = true;
                btnNhapExcel.Visible = true;
            }
        }

        private void HienThiDanhSach(List<SinhVien> list)
        {
            dgvSinhVien.Rows.Clear();
            foreach (var sv in list)
            {
                dgvSinhVien.Rows.Add(sv.MSSV, sv.HoTen, sv.Lop, sv.SoDe);
            }
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            string keyword = txtTimKiem.Text.Trim().ToLower();
            if (string.IsNullOrEmpty(keyword))
            {
                HienThiDanhSach(DataStore.DanhSachSinhVien);
                return;
            }

            var ketQua = DataStore.DanhSachSinhVien.Where(s =>
                s.MSSV.ToLower().Contains(keyword) ||
                s.HoTen.ToLower().Contains(keyword) ||
                s.Lop.ToLower().Contains(keyword)
            ).ToList();

            HienThiDanhSach(ketQua);
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            // Mở hộp thoại nhập thông tin sinh viên
            using (Form prompt = new Form())
            {
                prompt.Width = 420;
                prompt.Height = 370;
                prompt.FormBorderStyle = FormBorderStyle.FixedDialog;
                prompt.Text = "Thêm sinh viên mới";
                prompt.StartPosition = FormStartPosition.CenterParent;
                prompt.BackColor = Color.FromArgb(255, 235, 245);

                Label lblMSSV = new Label() { Left = 20, Top = 25, Text = "MSSV:", Width = 90 };
                TextBox txtMSSV = new TextBox() { Left = 120, Top = 22, Width = 250 };

                Label lblHoTen = new Label() { Left = 20, Top = 70, Text = "Họ và tên:", Width = 90 };
                TextBox txtHoTen = new TextBox() { Left = 120, Top = 67, Width = 250 };

                Label lblLop = new Label() { Left = 20, Top = 115, Text = "Lớp:", Width = 90 };
                TextBox txtLop = new TextBox() { Left = 120, Top = 112, Width = 250 };

                Label lblMatKhau = new Label() { Left = 20, Top = 160, Text = "Mật khẩu:", Width = 90 };
                TextBox txtMatKhau = new TextBox() { Left = 120, Top = 157, Width = 250, Text = "123" };

                Label lblSoDe = new Label() { Left = 20, Top = 205, Text = "Số đề thi:", Width = 90 };
                NumericUpDown nudSoDe = new NumericUpDown() { Left = 120, Top = 202, Width = 120, Maximum = 100 };

                Button btnLuu = new Button() { Text = "Lưu", Left = 150, Width = 100, Top = 265, DialogResult = DialogResult.OK, BackColor = Color.FromArgb(255, 190, 220) };
                Button btnHuy = new Button() { Text = "Hủy", Left = 270, Width = 100, Top = 265, DialogResult = DialogResult.Cancel };

                prompt.Controls.Add(lblMSSV);
                prompt.Controls.Add(txtMSSV);
                prompt.Controls.Add(lblHoTen);
                prompt.Controls.Add(txtHoTen);
                prompt.Controls.Add(lblLop);
                prompt.Controls.Add(txtLop);
                prompt.Controls.Add(lblMatKhau);
                prompt.Controls.Add(txtMatKhau);
                prompt.Controls.Add(lblSoDe);
                prompt.Controls.Add(nudSoDe);
                prompt.Controls.Add(btnLuu);
                prompt.Controls.Add(btnHuy);
                prompt.AcceptButton = btnLuu;

                if (prompt.ShowDialog(this) == DialogResult.OK)
                {
                    string mssv = txtMSSV.Text.Trim();
                    string hoTen = txtHoTen.Text.Trim();
                    string lop = txtLop.Text.Trim();
                    string matKhau = txtMatKhau.Text.Trim();
                    if (string.IsNullOrEmpty(matKhau)) matKhau = "123";
                    int soDe = (int)nudSoDe.Value;

                    if (string.IsNullOrEmpty(mssv) || string.IsNullOrEmpty(hoTen))
                    {
                        MessageBox.Show("MSSV và Họ tên không được để trống!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (DataStore.DanhSachSinhVien.Any(s => s.MSSV.Equals(mssv, StringComparison.OrdinalIgnoreCase)))
                    {
                        MessageBox.Show("Mã số sinh viên này đã tồn tại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    DataStore.DanhSachSinhVien.Add(new SinhVien(mssv, hoTen, lop, soDe));

                    // Tự động tạo tài khoản đăng nhập cho sinh viên
                    var tk = DataStore.DanhSachTaiKhoan.FirstOrDefault(t => t.MSSV.Equals(mssv, StringComparison.OrdinalIgnoreCase) || t.TenDangNhap.Equals(mssv, StringComparison.OrdinalIgnoreCase));
                    if (tk == null)
                    {
                        DataStore.DanhSachTaiKhoan.Add(new TaiKhoan(mssv, matKhau, "Sinh viên", mssv, hoTen, lop));
                    }

                    DataStore.NotifyDataChanged();
                    HienThiDanhSach(DataStore.DanhSachSinhVien);
                    MessageBox.Show(string.Format("Thêm sinh viên thành công!\nTài khoản đăng nhập: {0}\nMật khẩu: {1}", mssv, matKhau), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (dgvSinhVien.CurrentRow == null || dgvSinhVien.CurrentRow.Index < 0)
            {
                MessageBox.Show("Vui lòng chọn sinh viên cần sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string mssv = dgvSinhVien.CurrentRow.Cells[0].Value?.ToString();
            var sv = DataStore.DanhSachSinhVien.FirstOrDefault(s => s.MSSV == mssv);
            if (sv == null) return;

            using (Form prompt = new Form())
            {
                prompt.Width = 420;
                prompt.Height = 320;
                prompt.FormBorderStyle = FormBorderStyle.FixedDialog;
                prompt.Text = "Sửa thông tin sinh viên";
                prompt.StartPosition = FormStartPosition.CenterParent;
                prompt.BackColor = Color.FromArgb(255, 235, 245);

                Label lblMSSV = new Label() { Left = 20, Top = 25, Text = "MSSV:", Width = 90 };
                TextBox txtMSSV = new TextBox() { Left = 120, Top = 22, Width = 250, Text = sv.MSSV, ReadOnly = true };

                Label lblHoTen = new Label() { Left = 20, Top = 70, Text = "Họ và tên:", Width = 90 };
                TextBox txtHoTen = new TextBox() { Left = 120, Top = 67, Width = 250, Text = sv.HoTen };

                Label lblLop = new Label() { Left = 20, Top = 115, Text = "Lớp:", Width = 90 };
                TextBox txtLop = new TextBox() { Left = 120, Top = 112, Width = 250, Text = sv.Lop };

                Label lblSoDe = new Label() { Left = 20, Top = 160, Text = "Số đề thi:", Width = 90 };
                NumericUpDown nudSoDe = new NumericUpDown() { Left = 120, Top = 157, Width = 120, Maximum = 100, Value = sv.SoDe };

                Button btnLuu = new Button() { Text = "Cập nhật", Left = 150, Width = 100, Top = 215, DialogResult = DialogResult.OK, BackColor = Color.FromArgb(255, 190, 220) };
                Button btnHuy = new Button() { Text = "Hủy", Left = 270, Width = 100, Top = 215, DialogResult = DialogResult.Cancel };

                prompt.Controls.Add(lblMSSV);
                prompt.Controls.Add(txtMSSV);
                prompt.Controls.Add(lblHoTen);
                prompt.Controls.Add(txtHoTen);
                prompt.Controls.Add(lblLop);
                prompt.Controls.Add(txtLop);
                prompt.Controls.Add(lblSoDe);
                prompt.Controls.Add(nudSoDe);
                prompt.Controls.Add(btnLuu);
                prompt.Controls.Add(btnHuy);
                prompt.AcceptButton = btnLuu;

                if (prompt.ShowDialog(this) == DialogResult.OK)
                {
                    sv.HoTen = txtHoTen.Text.Trim();
                    sv.Lop = txtLop.Text.Trim();
                    sv.SoDe = (int)nudSoDe.Value;

                    var tk = DataStore.DanhSachTaiKhoan.FirstOrDefault(t => t.MSSV.Equals(sv.MSSV, StringComparison.OrdinalIgnoreCase) || t.TenDangNhap.Equals(sv.MSSV, StringComparison.OrdinalIgnoreCase));
                    if (tk != null)
                    {
                        tk.HoTen = sv.HoTen;
                        tk.Lop = sv.Lop;
                    }

                    DataStore.NotifyDataChanged();
                    HienThiDanhSach(DataStore.DanhSachSinhVien);
                    MessageBox.Show("Cập nhật sinh viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dgvSinhVien.CurrentRow == null || dgvSinhVien.CurrentRow.Index < 0)
            {
                MessageBox.Show("Vui lòng chọn sinh viên cần xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string mssv = dgvSinhVien.CurrentRow.Cells[0].Value?.ToString();
            var sv = DataStore.DanhSachSinhVien.FirstOrDefault(s => s.MSSV == mssv);
            if (sv == null) return;

            DialogResult dr = MessageBox.Show(string.Format("Bạn có chắc chắn muốn xóa sinh viên \"{0}\"?", sv.HoTen), "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                DataStore.DanhSachSinhVien.Remove(sv);
                DataStore.DanhSachTaiKhoan.RemoveAll(t => t.MSSV.Equals(sv.MSSV, StringComparison.OrdinalIgnoreCase) || t.TenDangNhap.Equals(sv.MSSV, StringComparison.OrdinalIgnoreCase));
                DataStore.NotifyDataChanged();
                HienThiDanhSach(DataStore.DanhSachSinhVien);
                MessageBox.Show("Đã xóa sinh viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Tải file từ máy tính vào hệ thống
        private void btnNhapExcel_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Title = "Chọn file Excel / Danh sách sinh viên";
                ofd.Filter = "Tất cả định dạng hỗ trợ (*.xlsx;*.xls;*.csv;*.txt)|*.xlsx;*.xls;*.csv;*.txt|File Excel (*.xlsx;*.xls)|*.xlsx;*.xls|File CSV (*.csv)|*.csv|File Text (*.txt)|*.txt|Tất cả tập tin (*.*)|*.*";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        int dem = DataStore.DocSinhVienTuFile(ofd.FileName);
                        HienThiDanhSach(DataStore.DanhSachSinhVien);
                        MessageBox.Show(string.Format("Đã tải thành công {0} sinh viên từ file!\nHệ thống đã tự động tạo tài khoản đăng nhập cho toàn bộ sinh viên (mật khẩu mặc định: 123).", dem), "Tải file thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi khi đọc file: " + ex.Message, "Lỗi tải file", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}
