using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace dethitracnghiem
{
    public partial class FrmNhapCauHoi : Form
    {
        private string vaiTro;
        private List<CauHoi> danhSachHienThi = new List<CauHoi>();

        public FrmNhapCauHoi()
        {
            InitializeComponent();
            this.vaiTro = DataStore.VaiTroHienTai;
        }

        public FrmNhapCauHoi(string role) : this()
        {
            this.vaiTro = role;
        }

        private void FrmNhapCauHoi_Load(object sender, EventArgs e)
        {
            ApDungPhanQuyen();
            NapMonHoc();
        }

        private void ApDungPhanQuyen()
        {
            if (vaiTro == "Sinh viên")
            {
                // Khi là sinh viên: không hiển thị nút thêm sửa xóa và tải file
                btnThem.Visible = false;
                btnSua.Visible = false;
                btnXoa.Visible = false;
                btnTaiFile.Visible = false;
                btnLamMoi.Visible = false;

                txtNoiDung.ReadOnly = true;
                txtA.ReadOnly = true;
                txtB.ReadOnly = true;
                txtC.ReadOnly = true;
                txtD.ReadOnly = true;
                cboDapAnDung.Enabled = false;
            }
            else
            {
                // Quản trị viên: đầy đủ đặc quyền
                btnThem.Visible = true;
                btnSua.Visible = true;
                btnXoa.Visible = true;
                btnTaiFile.Visible = true;
                btnLamMoi.Visible = true;

                txtNoiDung.ReadOnly = false;
                txtA.ReadOnly = false;
                txtB.ReadOnly = false;
                txtC.ReadOnly = false;
                txtD.ReadOnly = false;
                cboDapAnDung.Enabled = true;
            }
        }

        private void NapMonHoc()
        {
            cboMonHoc.Items.Clear();
            cboMonHoc.Items.Add(new MonHocItem { MaMon = "ALL", TenMon = "--- Tất cả môn học ---" });
            foreach (var mh in DataStore.DanhSachMonHoc)
            {
                cboMonHoc.Items.Add(new MonHocItem { MaMon = mh.MaMon, TenMon = mh.TenMon });
            }

            if (cboMonHoc.Items.Count > 1)
            {
                cboMonHoc.SelectedIndex = 1; // Chọn môn đầu tiên (Lập trình C#)
            }
            else if (cboMonHoc.Items.Count > 0)
            {
                cboMonHoc.SelectedIndex = 0;
            }
        }

        private class MonHocItem
        {
            public string MaMon { get; set; }
            public string TenMon { get; set; }
            public override string ToString() => TenMon;
        }

        private void cboMonHoc_SelectedIndexChanged(object sender, EventArgs e)
        {
            NapDanhSachCauHoi();
        }

        private void NapDanhSachCauHoi()
        {
            MonHocItem item = cboMonHoc.SelectedItem as MonHocItem;
            if (item == null) return;

            if (item.MaMon == "ALL")
            {
                danhSachHienThi = new List<CauHoi>(DataStore.DanhSachCauHoi);
            }
            else
            {
                danhSachHienThi = DataStore.DanhSachCauHoi.Where(c => c.MaMon == item.MaMon).ToList();
            }

            dgvCauHoi.Rows.Clear();
            int stt = 1;
            foreach (var ch in danhSachHienThi)
            {
                dgvCauHoi.Rows.Add(stt++, ch.NoiDung, ch.DapAnA, ch.DapAnB, ch.DapAnC, ch.DapAnD, ch.DapAnDung);
            }

            if (dgvCauHoi.Rows.Count > 0)
            {
                dgvCauHoi.Rows[0].Selected = true;
            }
            else
            {
                btnLamMoi_Click(null, null);
            }
        }

        private void dgvCauHoi_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvCauHoi.CurrentRow == null || dgvCauHoi.CurrentRow.Index < 0 || dgvCauHoi.CurrentRow.Index >= danhSachHienThi.Count)
                return;

            CauHoi ch = danhSachHienThi[dgvCauHoi.CurrentRow.Index];
            txtNoiDung.Text = ch.NoiDung;
            txtA.Text = ch.DapAnA;
            txtB.Text = ch.DapAnB;
            txtC.Text = ch.DapAnC;
            txtD.Text = ch.DapAnD;

            for (int i = 0; i < cboDapAnDung.Items.Count; i++)
            {
                if (string.Equals(cboDapAnDung.Items[i].ToString(), ch.DapAnDung, StringComparison.OrdinalIgnoreCase))
                {
                    cboDapAnDung.SelectedIndex = i;
                    break;
                }
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            string noiDung = txtNoiDung.Text.Trim();
            string a = txtA.Text.Trim();
            string b = txtB.Text.Trim();
            string c = txtC.Text.Trim();
            string d = txtD.Text.Trim();
            string dung = cboDapAnDung.SelectedItem?.ToString() ?? "A";

            if (string.IsNullOrEmpty(noiDung) || string.IsNullOrEmpty(a) || string.IsNullOrEmpty(b))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ nội dung câu hỏi và các đáp án!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MonHocItem item = cboMonHoc.SelectedItem as MonHocItem;
            string maMon = (item != null && item.MaMon != "ALL") ? item.MaMon : (DataStore.DanhSachMonHoc.Count > 0 ? DataStore.DanhSachMonHoc[0].MaMon : "");

            if (string.IsNullOrEmpty(maMon))
            {
                MessageBox.Show("Hệ thống chưa có môn học nào! Vui lòng thêm môn học trước.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int nextId = DataStore.DanhSachCauHoi.Count > 0 ? DataStore.DanhSachCauHoi.Max(x => x.Id) + 1 : 1;
            CauHoi ch = new CauHoi(nextId, maMon, noiDung, a, b, c, d, dung);

            DataStore.DanhSachCauHoi.Add(ch);
            DataStore.NotifyDataChanged();

            NapDanhSachCauHoi();
            MessageBox.Show("Đã thêm câu hỏi thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (dgvCauHoi.CurrentRow == null || dgvCauHoi.CurrentRow.Index < 0 || dgvCauHoi.CurrentRow.Index >= danhSachHienThi.Count)
            {
                MessageBox.Show("Vui lòng chọn câu hỏi cần sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            CauHoi ch = danhSachHienThi[dgvCauHoi.CurrentRow.Index];
            string noiDung = txtNoiDung.Text.Trim();
            string a = txtA.Text.Trim();
            string b = txtB.Text.Trim();
            string c = txtC.Text.Trim();
            string d = txtD.Text.Trim();
            string dung = cboDapAnDung.SelectedItem?.ToString() ?? "A";

            if (string.IsNullOrEmpty(noiDung))
            {
                MessageBox.Show("Nội dung câu hỏi không được để trống!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ch.NoiDung = noiDung;
            ch.DapAnA = a;
            ch.DapAnB = b;
            ch.DapAnC = c;
            ch.DapAnD = d;
            ch.DapAnDung = dung;

            DataStore.NotifyDataChanged();
            NapDanhSachCauHoi();
            MessageBox.Show("Đã cập nhật câu hỏi thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dgvCauHoi.CurrentRow == null || dgvCauHoi.CurrentRow.Index < 0 || dgvCauHoi.CurrentRow.Index >= danhSachHienThi.Count)
            {
                MessageBox.Show("Vui lòng chọn câu hỏi cần xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            CauHoi ch = danhSachHienThi[dgvCauHoi.CurrentRow.Index];
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muốn xóa câu hỏi này?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                DataStore.DanhSachCauHoi.Remove(ch);
                DataStore.NotifyDataChanged();
                NapDanhSachCauHoi();
                MessageBox.Show("Đã xóa câu hỏi thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Tải file câu hỏi từ máy tính
        private void btnTaiFile_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Title = "Chọn file câu hỏi / Excel từ máy tính";
                ofd.Filter = "Tất cả định dạng hỗ trợ (*.xlsx;*.xls;*.csv;*.txt)|*.xlsx;*.xls;*.csv;*.txt|File Excel (*.xlsx;*.xls)|*.xlsx;*.xls|File Text (*.txt)|*.txt|File CSV (*.csv)|*.csv|Tất cả tập tin (*.*)|*.*";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        MonHocItem item = cboMonHoc.SelectedItem as MonHocItem;
                        string maMon = (item != null && item.MaMon != "ALL") ? item.MaMon : (DataStore.DanhSachMonHoc.Count > 0 ? DataStore.DanhSachMonHoc[0].MaMon : "");

                        int dem = DataStore.DocCauHoiTuFile(ofd.FileName, maMon);
                        NapDanhSachCauHoi();
                        MessageBox.Show(string.Format("Đã tải thành công {0} câu hỏi từ file!", dem), "Tải file thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi khi đọc file câu hỏi: " + ex.Message, "Lỗi tải file", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            txtNoiDung.Clear();
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txtD.Clear();
            if (cboDapAnDung.Items.Count > 0) cboDapAnDung.SelectedIndex = 0;
            txtNoiDung.Focus();
        }
    }
}
