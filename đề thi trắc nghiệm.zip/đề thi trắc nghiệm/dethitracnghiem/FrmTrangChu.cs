﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace dethitracnghiem
{
    public partial class FrmTrangChu : Form
    {
        private string vaiTro;

        public FrmTrangChu()
        {
            InitializeComponent();
            DataStore.DataChanged += CapNhatSoLieuTuHeThong;
        }

        public FrmTrangChu(string role) : this()
        {
            vaiTro = role;
        }

        private void FrmTrangChu_Load(object sender, EventArgs e)
        {
            CapNhatSoLieuTuHeThong();
        }

        public void CapNhatSoLieuTuHeThong()
        {
            if (this.IsDisposed || !this.IsHandleCreated) return;

            if (this.InvokeRequired)
            {
                this.Invoke(new Action(CapNhatSoLieuTuHeThong));
                return;
            }

            CapNhatTongSinhVien(DataStore.DanhSachSinhVien.Count);
            CapNhatTongMonHoc(DataStore.DanhSachMonHoc.Count);
            CapNhatTongCauHoi(DataStore.DanhSachCauHoi.Count);
            CapNhatTongDeThi(DataStore.DanhSachDeThi.Count);

            if (!string.IsNullOrEmpty(DataStore.HoTenHienTai))
            {
                lblChaoMung.Text = "CHÀO MỪNG " + DataStore.HoTenHienTai.ToUpper();
            }
        }

        public void CapNhatTongSinhVien(int tong)
        {
            lblTongSV.Text = tong.ToString();
        }

        public void CapNhatTongMonHoc(int tong)
        {
            lblTongMH.Text = tong.ToString();
        }

        public void CapNhatTongCauHoi(int tong)
        {
            lblTongCH.Text = tong.ToString();
        }

        public void CapNhatTongDeThi(int tong)
        {
            lblTongDT.Text = tong.ToString();
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            DataStore.DataChanged -= CapNhatSoLieuTuHeThong;
            base.OnFormClosed(e);
        }
    }
}
