﻿namespace dethitracnghiem
{
    partial class FrmTrangChu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTieuDe = new System.Windows.Forms.Panel();
            this.lblChaoMung = new System.Windows.Forms.Label();
            this.pnlSinhVien = new System.Windows.Forms.Panel();
            this.lblTongSV = new System.Windows.Forms.Label();
            this.lblTieuDeSV = new System.Windows.Forms.Label();
            this.pnlMonHoc = new System.Windows.Forms.Panel();
            this.lblTongMH = new System.Windows.Forms.Label();
            this.lblTieuDeMH = new System.Windows.Forms.Label();
            this.pnlCauHoi = new System.Windows.Forms.Panel();
            this.lblTongCH = new System.Windows.Forms.Label();
            this.lblTieuDeCH = new System.Windows.Forms.Label();
            this.pnlDeThi = new System.Windows.Forms.Panel();
            this.lblTongDT = new System.Windows.Forms.Label();
            this.lblTieuDeDT = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlTieuDe.SuspendLayout();
            this.pnlSinhVien.SuspendLayout();
            this.pnlMonHoc.SuspendLayout();
            this.pnlCauHoi.SuspendLayout();
            this.pnlDeThi.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTieuDe
            // 
            this.pnlTieuDe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(239)))));
            this.pnlTieuDe.Controls.Add(this.lblChaoMung);
            this.pnlTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTieuDe.Location = new System.Drawing.Point(0, 0);
            this.pnlTieuDe.Name = "pnlTieuDe";
            this.pnlTieuDe.Size = new System.Drawing.Size(800, 75);
            this.pnlTieuDe.TabIndex = 0;
            // 
            // lblChaoMung
            // 
            this.lblChaoMung.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChaoMung.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(45)))), ((int)(((byte)(105)))));
            this.lblChaoMung.Location = new System.Drawing.Point(116, 12);
            this.lblChaoMung.Name = "lblChaoMung";
            this.lblChaoMung.Size = new System.Drawing.Size(584, 48);
            this.lblChaoMung.TabIndex = 0;
            this.lblChaoMung.Text = "CHÀO MỪNG ĐẾN VỚI HỆ THỐNG";
            this.lblChaoMung.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlSinhVien
            // 
            this.pnlSinhVien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(228)))), ((int)(((byte)(239)))));
            this.pnlSinhVien.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSinhVien.Controls.Add(this.lblTongSV);
            this.pnlSinhVien.Controls.Add(this.lblTieuDeSV);
            this.pnlSinhVien.Location = new System.Drawing.Point(47, 98);
            this.pnlSinhVien.Name = "pnlSinhVien";
            this.pnlSinhVien.Size = new System.Drawing.Size(344, 150);
            this.pnlSinhVien.TabIndex = 1;
            // 
            // lblTongSV
            // 
            this.lblTongSV.Font = new System.Drawing.Font("Segoe UI", 32F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongSV.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(45)))), ((int)(((byte)(105)))));
            this.lblTongSV.Location = new System.Drawing.Point(25, 65);
            this.lblTongSV.Name = "lblTongSV";
            this.lblTongSV.Size = new System.Drawing.Size(280, 65);
            this.lblTongSV.TabIndex = 1;
            this.lblTongSV.Text = "0";
            this.lblTongSV.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTieuDeSV
            // 
            this.lblTieuDeSV.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDeSV.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(45)))), ((int)(((byte)(105)))));
            this.lblTieuDeSV.Location = new System.Drawing.Point(18, 18);
            this.lblTieuDeSV.Name = "lblTieuDeSV";
            this.lblTieuDeSV.Size = new System.Drawing.Size(305, 38);
            this.lblTieuDeSV.TabIndex = 0;
            this.lblTieuDeSV.Text = "👥  Tổng sinh viên";
            // 
            // pnlMonHoc
            // 
            this.pnlMonHoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(231)))), ((int)(((byte)(255)))));
            this.pnlMonHoc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlMonHoc.Controls.Add(this.lblTongMH);
            this.pnlMonHoc.Controls.Add(this.lblTieuDeMH);
            this.pnlMonHoc.Location = new System.Drawing.Point(409, 98);
            this.pnlMonHoc.Name = "pnlMonHoc";
            this.pnlMonHoc.Size = new System.Drawing.Size(344, 150);
            this.pnlMonHoc.TabIndex = 2;
            // 
            // lblTongMH
            // 
            this.lblTongMH.Font = new System.Drawing.Font("Segoe UI", 32F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongMH.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(160)))), ((int)(((byte)(160)))));
            this.lblTongMH.Location = new System.Drawing.Point(25, 65);
            this.lblTongMH.Name = "lblTongMH";
            this.lblTongMH.Size = new System.Drawing.Size(280, 65);
            this.lblTongMH.TabIndex = 2;
            this.lblTongMH.Text = "0";
            this.lblTongMH.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTieuDeMH
            // 
            this.lblTieuDeMH.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDeMH.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(160)))), ((int)(((byte)(160)))));
            this.lblTieuDeMH.Location = new System.Drawing.Point(18, 18);
            this.lblTieuDeMH.Name = "lblTieuDeMH";
            this.lblTieuDeMH.Size = new System.Drawing.Size(305, 38);
            this.lblTieuDeMH.TabIndex = 3;
            this.lblTieuDeMH.Text = "📖  Tổng môn học";
            // 
            // pnlCauHoi
            // 
            this.pnlCauHoi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.pnlCauHoi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCauHoi.Controls.Add(this.lblTongCH);
            this.pnlCauHoi.Controls.Add(this.lblTieuDeCH);
            this.pnlCauHoi.Location = new System.Drawing.Point(47, 254);
            this.pnlCauHoi.Name = "pnlCauHoi";
            this.pnlCauHoi.Size = new System.Drawing.Size(344, 150);
            this.pnlCauHoi.TabIndex = 2;
            // 
            // lblTongCH
            // 
            this.lblTongCH.Font = new System.Drawing.Font("Segoe UI", 32F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongCH.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(150)))), ((int)(((byte)(55)))));
            this.lblTongCH.Location = new System.Drawing.Point(25, 65);
            this.lblTongCH.Name = "lblTongCH";
            this.lblTongCH.Size = new System.Drawing.Size(280, 65);
            this.lblTongCH.TabIndex = 2;
            this.lblTongCH.Text = "0";
            this.lblTongCH.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTieuDeCH
            // 
            this.lblTieuDeCH.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDeCH.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(150)))), ((int)(((byte)(55)))));
            this.lblTieuDeCH.Location = new System.Drawing.Point(18, 18);
            this.lblTieuDeCH.Name = "lblTieuDeCH";
            this.lblTieuDeCH.Size = new System.Drawing.Size(305, 38);
            this.lblTieuDeCH.TabIndex = 4;
            this.lblTieuDeCH.Text = "❓  Tổng câu hỏi";
            // 
            // pnlDeThi
            // 
            this.pnlDeThi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(241)))), ((int)(((byte)(220)))));
            this.pnlDeThi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDeThi.Controls.Add(this.lblTongDT);
            this.pnlDeThi.Controls.Add(this.lblTieuDeDT);
            this.pnlDeThi.Location = new System.Drawing.Point(409, 254);
            this.pnlDeThi.Name = "pnlDeThi";
            this.pnlDeThi.Size = new System.Drawing.Size(344, 150);
            this.pnlDeThi.TabIndex = 2;
            // 
            // lblTongDT
            // 
            this.lblTongDT.Font = new System.Drawing.Font("Segoe UI", 32F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongDT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(95)))), ((int)(((byte)(80)))));
            this.lblTongDT.Location = new System.Drawing.Point(25, 65);
            this.lblTongDT.Name = "lblTongDT";
            this.lblTongDT.Size = new System.Drawing.Size(280, 65);
            this.lblTongDT.TabIndex = 5;
            this.lblTongDT.Text = "0";
            this.lblTongDT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTieuDeDT
            // 
            this.lblTieuDeDT.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDeDT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(95)))), ((int)(((byte)(80)))));
            this.lblTieuDeDT.Location = new System.Drawing.Point(18, 18);
            this.lblTieuDeDT.Name = "lblTieuDeDT";
            this.lblTieuDeDT.Size = new System.Drawing.Size(305, 38);
            this.lblTieuDeDT.TabIndex = 2;
            this.lblTieuDeDT.Text = "📃  Tổng đề thi";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(185, 435);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(456, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Chúc bạn có một buổi học tập và kiểm tra hiệu quả!";
            // 
            // FrmTrangChu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 492);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pnlDeThi);
            this.Controls.Add(this.pnlCauHoi);
            this.Controls.Add(this.pnlMonHoc);
            this.Controls.Add(this.pnlSinhVien);
            this.Controls.Add(this.pnlTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmTrangChu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Trang chủ";
            this.Load += new System.EventHandler(this.FrmTrangChu_Load);
            this.pnlTieuDe.ResumeLayout(false);
            this.pnlSinhVien.ResumeLayout(false);
            this.pnlSinhVien.PerformLayout();
            this.pnlMonHoc.ResumeLayout(false);
            this.pnlMonHoc.PerformLayout();
            this.pnlCauHoi.ResumeLayout(false);
            this.pnlCauHoi.PerformLayout();
            this.pnlDeThi.ResumeLayout(false);
            this.pnlDeThi.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlTieuDe;
        private System.Windows.Forms.Label lblChaoMung;
        private System.Windows.Forms.Panel pnlSinhVien;
        private System.Windows.Forms.Panel pnlMonHoc;
        private System.Windows.Forms.Panel pnlCauHoi;
        private System.Windows.Forms.Panel pnlDeThi;
        private System.Windows.Forms.Label lblTongSV;
        private System.Windows.Forms.Label lblTieuDeSV;
        private System.Windows.Forms.Label lblTongMH;
        private System.Windows.Forms.Label lblTieuDeMH;
        private System.Windows.Forms.Label lblTongCH;
        private System.Windows.Forms.Label lblTieuDeCH;
        private System.Windows.Forms.Label lblTongDT;
        private System.Windows.Forms.Label lblTieuDeDT;
        private System.Windows.Forms.Label label1;
    }
}