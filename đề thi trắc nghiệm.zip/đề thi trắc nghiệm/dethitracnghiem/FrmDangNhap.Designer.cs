namespace dethitracnghiem
{
    partial class FrmDangNhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTrai = new System.Windows.Forms.Panel();
            this.lblSlogan = new System.Windows.Forms.Label();
            this.lblTenPhanMem = new System.Windows.Forms.Label();
            this.picMeo = new System.Windows.Forms.PictureBox();
            this.pnlPhai = new System.Windows.Forms.Panel();
            this.btnDangKy = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnDangNhap = new System.Windows.Forms.Button();
            this.rdoQuanTriVien = new System.Windows.Forms.RadioButton();
            this.rdoSinhVien = new System.Windows.Forms.RadioButton();
            this.lblVaiTro = new System.Windows.Forms.Label();
            this.lblMatKhau = new System.Windows.Forms.Label();
            this.lblTaiKhoan = new System.Windows.Forms.Label();
            this.txtMatKhau = new System.Windows.Forms.TextBox();
            this.txtTenDangNhap = new System.Windows.Forms.TextBox();
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.pnlTrai.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picMeo)).BeginInit();
            this.pnlPhai.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTrai
            // 
            this.pnlTrai.Controls.Add(this.lblSlogan);
            this.pnlTrai.Controls.Add(this.lblTenPhanMem);
            this.pnlTrai.Controls.Add(this.picMeo);
            this.pnlTrai.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlTrai.ForeColor = System.Drawing.Color.Fuchsia;
            this.pnlTrai.Location = new System.Drawing.Point(0, 0);
            this.pnlTrai.Name = "pnlTrai";
            this.pnlTrai.Size = new System.Drawing.Size(411, 566);
            this.pnlTrai.TabIndex = 0;
            // 
            // lblSlogan
            // 
            this.lblSlogan.AutoSize = true;
            this.lblSlogan.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSlogan.ForeColor = System.Drawing.Color.Fuchsia;
            this.lblSlogan.Location = new System.Drawing.Point(97, 356);
            this.lblSlogan.Name = "lblSlogan";
            this.lblSlogan.Size = new System.Drawing.Size(218, 28);
            this.lblSlogan.TabIndex = 2;
            this.lblSlogan.Text = "-Học tập dễ dàng hơn!-";
            this.lblSlogan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTenPhanMem
            // 
            this.lblTenPhanMem.AutoSize = true;
            this.lblTenPhanMem.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenPhanMem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(45)))), ((int)(((byte)(110)))));
            this.lblTenPhanMem.Location = new System.Drawing.Point(10, 298);
            this.lblTenPhanMem.Name = "lblTenPhanMem";
            this.lblTenPhanMem.Size = new System.Drawing.Size(385, 45);
            this.lblTenPhanMem.TabIndex = 1;
            this.lblTenPhanMem.Text = "Quản lý thi trắc nghiệm";
            // 
            // picMeo
            // 
            this.picMeo.Image = global::dethitracnghiem.Properties.Resources.anh;
            this.picMeo.Location = new System.Drawing.Point(64, 52);
            this.picMeo.Name = "picMeo";
            this.picMeo.Size = new System.Drawing.Size(278, 224);
            this.picMeo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picMeo.TabIndex = 0;
            this.picMeo.TabStop = false;
            // 
            // pnlPhai
            // 
            this.pnlPhai.Controls.Add(this.btnDangKy);
            this.pnlPhai.Controls.Add(this.btnThoat);
            this.pnlPhai.Controls.Add(this.btnDangNhap);
            this.pnlPhai.Controls.Add(this.rdoQuanTriVien);
            this.pnlPhai.Controls.Add(this.rdoSinhVien);
            this.pnlPhai.Controls.Add(this.lblVaiTro);
            this.pnlPhai.Controls.Add(this.lblMatKhau);
            this.pnlPhai.Controls.Add(this.lblTaiKhoan);
            this.pnlPhai.Controls.Add(this.txtMatKhau);
            this.pnlPhai.Controls.Add(this.txtTenDangNhap);
            this.pnlPhai.Controls.Add(this.lblTieuDe);
            this.pnlPhai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPhai.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(30)))), ((int)(((byte)(85)))));
            this.pnlPhai.Location = new System.Drawing.Point(411, 0);
            this.pnlPhai.Name = "pnlPhai";
            this.pnlPhai.Size = new System.Drawing.Size(441, 566);
            this.pnlPhai.TabIndex = 1;
            // 
            // btnDangKy
            // 
            this.btnDangKy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(235)))));
            this.btnDangKy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDangKy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDangKy.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangKy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(30)))), ((int)(((byte)(85)))));
            this.btnDangKy.Location = new System.Drawing.Point(64, 478);
            this.btnDangKy.Name = "btnDangKy";
            this.btnDangKy.Size = new System.Drawing.Size(307, 38);
            this.btnDangKy.TabIndex = 10;
            this.btnDangKy.Text = "➕ Đăng ký tài khoản Sinh viên";
            this.btnDangKy.UseVisualStyleBackColor = false;
            this.btnDangKy.Click += new System.EventHandler(this.btnDangKy_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThoat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(35)))), ((int)(((byte)(90)))));
            this.btnThoat.Location = new System.Drawing.Point(246, 423);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(125, 42);
            this.btnThoat.TabIndex = 9;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;

            // 
            // btnDangNhap
            // 
            this.btnDangNhap.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(65)))), ((int)(((byte)(125)))));
            this.btnDangNhap.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDangNhap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDangNhap.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangNhap.ForeColor = System.Drawing.Color.White;
            this.btnDangNhap.Location = new System.Drawing.Point(64, 423);
            this.btnDangNhap.Name = "btnDangNhap";
            this.btnDangNhap.Size = new System.Drawing.Size(170, 40);
            this.btnDangNhap.TabIndex = 8;
            this.btnDangNhap.Text = "➜ Đăng nhập";
            this.btnDangNhap.UseVisualStyleBackColor = false;
            this.btnDangNhap.Click += new System.EventHandler(this.btnDangNhap_Click);
            // 
            // rdoQuanTriVien
            // 
            this.rdoQuanTriVien.AutoSize = true;
            this.rdoQuanTriVien.Location = new System.Drawing.Point(246, 336);
            this.rdoQuanTriVien.Name = "rdoQuanTriVien";
            this.rdoQuanTriVien.Size = new System.Drawing.Size(125, 24);
            this.rdoQuanTriVien.TabIndex = 7;
            this.rdoQuanTriVien.Text = "Quản trị viên";
            this.rdoQuanTriVien.UseVisualStyleBackColor = true;
            // 
            // rdoSinhVien
            // 
            this.rdoSinhVien.AutoSize = true;
            this.rdoSinhVien.Location = new System.Drawing.Point(77, 336);
            this.rdoSinhVien.Name = "rdoSinhVien";
            this.rdoSinhVien.Size = new System.Drawing.Size(98, 24);
            this.rdoSinhVien.TabIndex = 6;
            this.rdoSinhVien.Text = "Sinh viên";
            this.rdoSinhVien.UseVisualStyleBackColor = true;
            // 
            // lblVaiTro
            // 
            this.lblVaiTro.AutoSize = true;
            this.lblVaiTro.Location = new System.Drawing.Point(23, 279);
            this.lblVaiTro.Name = "lblVaiTro";
            this.lblVaiTro.Size = new System.Drawing.Size(63, 20);
            this.lblVaiTro.TabIndex = 5;
            this.lblVaiTro.Text = "Vai trò:";
            // 
            // lblMatKhau
            // 
            this.lblMatKhau.AutoSize = true;
            this.lblMatKhau.Location = new System.Drawing.Point(23, 223);
            this.lblMatKhau.Name = "lblMatKhau";
            this.lblMatKhau.Size = new System.Drawing.Size(77, 20);
            this.lblMatKhau.TabIndex = 4;
            this.lblMatKhau.Text = "Mật khẩu";
            // 
            // lblTaiKhoan
            // 
            this.lblTaiKhoan.AutoSize = true;
            this.lblTaiKhoan.Location = new System.Drawing.Point(23, 167);
            this.lblTaiKhoan.Name = "lblTaiKhoan";
            this.lblTaiKhoan.Size = new System.Drawing.Size(119, 20);
            this.lblTaiKhoan.TabIndex = 3;
            this.lblTaiKhoan.Text = "Tên đăng nhập";
            // 
            // txtMatKhau
            // 
            this.txtMatKhau.Location = new System.Drawing.Point(157, 216);
            this.txtMatKhau.Name = "txtMatKhau";
            this.txtMatKhau.Size = new System.Drawing.Size(254, 27);
            this.txtMatKhau.TabIndex = 2;
            // 
            // txtTenDangNhap
            // 
            this.txtTenDangNhap.Location = new System.Drawing.Point(157, 160);
            this.txtTenDangNhap.Name = "txtTenDangNhap";
            this.txtTenDangNhap.Size = new System.Drawing.Size(254, 27);
            this.txtTenDangNhap.TabIndex = 1;
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDe.Location = new System.Drawing.Point(71, 52);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(300, 45);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "🔒 Đăng nhập";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FrmDangNhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(852, 566);
            this.Controls.Add(this.pnlPhai);
            this.Controls.Add(this.pnlTrai);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MinimizeBox = false;
            this.Name = "FrmDangNhap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Đăng nhập hệ thống";
            this.Load += new System.EventHandler(this.FrmDangNhap_Load);
            this.pnlTrai.ResumeLayout(false);
            this.pnlTrai.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picMeo)).EndInit();
            this.pnlPhai.ResumeLayout(false);
            this.pnlPhai.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTrai;
        private System.Windows.Forms.Panel pnlPhai;
        private System.Windows.Forms.Label lblSlogan;
        private System.Windows.Forms.Label lblTenPhanMem;
        private System.Windows.Forms.PictureBox picMeo;
        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.Label lblMatKhau;
        private System.Windows.Forms.Label lblTaiKhoan;
        private System.Windows.Forms.TextBox txtMatKhau;
        private System.Windows.Forms.TextBox txtTenDangNhap;
        private System.Windows.Forms.Label lblVaiTro;
        private System.Windows.Forms.RadioButton rdoQuanTriVien;
        private System.Windows.Forms.RadioButton rdoSinhVien;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnDangNhap;
        private System.Windows.Forms.Button btnDangKy;
    }
}

