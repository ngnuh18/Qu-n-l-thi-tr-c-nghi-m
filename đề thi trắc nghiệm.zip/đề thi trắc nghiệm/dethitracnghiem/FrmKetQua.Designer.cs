namespace dethitracnghiem
{
    partial class FrmKetQua
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.grpKetQua = new System.Windows.Forms.GroupBox();
            this.lblXepLoaiVal = new System.Windows.Forms.Label();
            this.lblDiemVal = new System.Windows.Forms.Label();
            this.lblMonThiVal = new System.Windows.Forms.Label();
            this.lblHoTenVal = new System.Windows.Forms.Label();
            this.lblXepLoai = new System.Windows.Forms.Label();
            this.lblDiem = new System.Windows.Forms.Label();
            this.lblMonThi = new System.Windows.Forms.Label();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.grpThongKe = new System.Windows.Forms.GroupBox();
            this.pnlBieuDo = new System.Windows.Forms.Panel();
            this.pnlChuThich = new System.Windows.Forms.Panel();
            this.btnXemChiTiet = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.pnlHeader.SuspendLayout();
            this.grpKetQua.SuspendLayout();
            this.grpThongKe.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlHeader
            // 
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(225)))), ((int)(((byte)(238)))));
            this.pnlHeader.Controls.Add(this.lblTieuDe);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(860, 48);
            this.pnlHeader.TabIndex = 0;
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.AutoSize = true;
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(40)))), ((int)(((byte)(100)))));
            this.lblTieuDe.Location = new System.Drawing.Point(18, 9);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(183, 31);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "📊 Kết quả bài thi";
            // 
            // grpKetQua
            // 
            this.grpKetQua.BackColor = System.Drawing.Color.White;
            this.grpKetQua.Controls.Add(this.lblXepLoaiVal);
            this.grpKetQua.Controls.Add(this.lblDiemVal);
            this.grpKetQua.Controls.Add(this.lblMonThiVal);
            this.grpKetQua.Controls.Add(this.lblHoTenVal);
            this.grpKetQua.Controls.Add(this.lblXepLoai);
            this.grpKetQua.Controls.Add(this.lblDiem);
            this.grpKetQua.Controls.Add(this.lblMonThi);
            this.grpKetQua.Controls.Add(this.lblHoTen);
            this.grpKetQua.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpKetQua.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(30)))), ((int)(((byte)(80)))));
            this.grpKetQua.Location = new System.Drawing.Point(24, 65);
            this.grpKetQua.Name = "grpKetQua";
            this.grpKetQua.Size = new System.Drawing.Size(390, 260);
            this.grpKetQua.TabIndex = 1;
            this.grpKetQua.TabStop = false;
            this.grpKetQua.Text = "Thông tin kết quả";
            // 
            // lblXepLoaiVal
            // 
            this.lblXepLoaiVal.AutoSize = true;
            this.lblXepLoaiVal.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXepLoaiVal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(40)))), ((int)(((byte)(100)))));
            this.lblXepLoaiVal.Location = new System.Drawing.Point(125, 190);
            this.lblXepLoaiVal.Name = "lblXepLoaiVal";
            this.lblXepLoaiVal.Size = new System.Drawing.Size(46, 25);
            this.lblXepLoaiVal.TabIndex = 7;
            this.lblXepLoaiVal.Text = "Giỏi";
            // 
            // lblDiemVal
            // 
            this.lblDiemVal.AutoSize = true;
            this.lblDiemVal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiemVal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(40)))), ((int)(((byte)(100)))));
            this.lblDiemVal.Location = new System.Drawing.Point(125, 140);
            this.lblDiemVal.Name = "lblDiemVal";
            this.lblDiemVal.Size = new System.Drawing.Size(41, 28);
            this.lblDiemVal.TabIndex = 6;
            this.lblDiemVal.Text = "8.5";
            // 
            // lblMonThiVal
            // 
            this.lblMonThiVal.AutoSize = true;
            this.lblMonThiVal.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMonThiVal.ForeColor = System.Drawing.Color.Black;
            this.lblMonThiVal.Location = new System.Drawing.Point(125, 92);
            this.lblMonThiVal.Name = "lblMonThiVal";
            this.lblMonThiVal.Size = new System.Drawing.Size(107, 23);
            this.lblMonThiVal.TabIndex = 5;
            this.lblMonThiVal.Text = "Lập trình C#";
            // 
            // lblHoTenVal
            // 
            this.lblHoTenVal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.lblHoTenVal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblHoTenVal.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHoTenVal.ForeColor = System.Drawing.Color.Black;
            this.lblHoTenVal.Location = new System.Drawing.Point(125, 38);
            this.lblHoTenVal.Name = "lblHoTenVal";
            this.lblHoTenVal.Padding = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.lblHoTenVal.Size = new System.Drawing.Size(245, 34);
            this.lblHoTenVal.TabIndex = 4;
            this.lblHoTenVal.Text = "Nguyễn Thị Yến Như";
            this.lblHoTenVal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblXepLoai
            // 
            this.lblXepLoai.AutoSize = true;
            this.lblXepLoai.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXepLoai.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.lblXepLoai.Location = new System.Drawing.Point(22, 191);
            this.lblXepLoai.Name = "lblXepLoai";
            this.lblXepLoai.Size = new System.Drawing.Size(75, 23);
            this.lblXepLoai.TabIndex = 3;
            this.lblXepLoai.Text = "Xếp loại:";
            // 
            // lblDiem
            // 
            this.lblDiem.AutoSize = true;
            this.lblDiem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.lblDiem.Location = new System.Drawing.Point(22, 143);
            this.lblDiem.Name = "lblDiem";
            this.lblDiem.Size = new System.Drawing.Size(55, 23);
            this.lblDiem.TabIndex = 2;
            this.lblDiem.Text = "Điểm:";
            // 
            // lblMonThi
            // 
            this.lblMonThi.AutoSize = true;
            this.lblMonThi.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMonThi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.lblMonThi.Location = new System.Drawing.Point(22, 92);
            this.lblMonThi.Name = "lblMonThi";
            this.lblMonThi.Size = new System.Drawing.Size(73, 23);
            this.lblMonThi.TabIndex = 1;
            this.lblMonThi.Text = "Môn thi:";
            // 
            // lblHoTen
            // 
            this.lblHoTen.AutoSize = true;
            this.lblHoTen.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHoTen.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.lblHoTen.Location = new System.Drawing.Point(22, 44);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(88, 23);
            this.lblHoTen.TabIndex = 0;
            this.lblHoTen.Text = "Họ và tên:";
            // 
            // grpThongKe
            // 
            this.grpThongKe.BackColor = System.Drawing.Color.White;
            this.grpThongKe.Controls.Add(this.pnlBieuDo);
            this.grpThongKe.Controls.Add(this.pnlChuThich);
            this.grpThongKe.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpThongKe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(30)))), ((int)(((byte)(80)))));
            this.grpThongKe.Location = new System.Drawing.Point(435, 65);
            this.grpThongKe.Name = "grpThongKe";
            this.grpThongKe.Size = new System.Drawing.Size(395, 260);
            this.grpThongKe.TabIndex = 2;
            this.grpThongKe.TabStop = false;
            this.grpThongKe.Text = "Thống kê";
            // 
            // pnlBieuDo
            // 
            this.pnlBieuDo.Location = new System.Drawing.Point(20, 35);
            this.pnlBieuDo.Name = "pnlBieuDo";
            this.pnlBieuDo.Size = new System.Drawing.Size(190, 190);
            this.pnlBieuDo.TabIndex = 0;
            // 
            // pnlChuThich
            // 
            this.pnlChuThich.Location = new System.Drawing.Point(220, 45);
            this.pnlChuThich.Name = "pnlChuThich";
            this.pnlChuThich.Size = new System.Drawing.Size(160, 180);
            this.pnlChuThich.TabIndex = 1;
            // 
            // btnXemChiTiet
            // 
            this.btnXemChiTiet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(235)))));
            this.btnXemChiTiet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnXemChiTiet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXemChiTiet.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemChiTiet.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(30)))), ((int)(((byte)(80)))));
            this.btnXemChiTiet.Location = new System.Drawing.Point(24, 345);
            this.btnXemChiTiet.Name = "btnXemChiTiet";
            this.btnXemChiTiet.Size = new System.Drawing.Size(180, 42);
            this.btnXemChiTiet.TabIndex = 3;
            this.btnXemChiTiet.Text = "🔍 Xem chi tiết";
            this.btnXemChiTiet.UseVisualStyleBackColor = false;
            this.btnXemChiTiet.Click += new System.EventHandler(this.btnXemChiTiet_Click);
            // 
            // btnDong
            // 
            this.btnDong.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(235)))));
            this.btnDong.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDong.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDong.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(30)))), ((int)(((byte)(80)))));
            this.btnDong.Location = new System.Drawing.Point(680, 345);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(150, 42);
            this.btnDong.TabIndex = 4;
            this.btnDong.Text = "❌ Đóng";
            this.btnDong.UseVisualStyleBackColor = false;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmKetQua
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(235)))), ((int)(((byte)(245)))));
            this.ClientSize = new System.Drawing.Size(860, 410);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnXemChiTiet);
            this.Controls.Add(this.grpThongKe);
            this.Controls.Add(this.grpKetQua);
            this.Controls.Add(this.pnlHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmKetQua";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kết quả bài thi";
            this.Load += new System.EventHandler(this.FrmKetQua_Load);
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.grpKetQua.ResumeLayout(false);
            this.grpKetQua.PerformLayout();
            this.grpThongKe.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.GroupBox grpKetQua;
        private System.Windows.Forms.Label lblXepLoaiVal;
        private System.Windows.Forms.Label lblDiemVal;
        private System.Windows.Forms.Label lblMonThiVal;
        private System.Windows.Forms.Label lblHoTenVal;
        private System.Windows.Forms.Label lblXepLoai;
        private System.Windows.Forms.Label lblDiem;
        private System.Windows.Forms.Label lblMonThi;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.GroupBox grpThongKe;
        private System.Windows.Forms.Panel pnlBieuDo;
        private System.Windows.Forms.Panel pnlChuThich;
        private System.Windows.Forms.Button btnXemChiTiet;
        private System.Windows.Forms.Button btnDong;
    }
}

