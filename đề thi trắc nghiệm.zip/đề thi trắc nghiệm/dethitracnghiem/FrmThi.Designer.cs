namespace dethitracnghiem
{
    partial class FrmThi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lblDongHo = new System.Windows.Forms.Label();
            this.lblTieuDeForm = new System.Windows.Forms.Label();
            this.pnlCard = new System.Windows.Forms.Panel();
            this.picMinhHoa = new System.Windows.Forms.PictureBox();
            this.rdoD = new System.Windows.Forms.RadioButton();
            this.rdoC = new System.Windows.Forms.RadioButton();
            this.rdoB = new System.Windows.Forms.RadioButton();
            this.rdoA = new System.Windows.Forms.RadioButton();
            this.lblNoiDungCauHoi = new System.Windows.Forms.Label();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnNopBai = new System.Windows.Forms.Button();
            this.btnTiepTheo = new System.Windows.Forms.Button();
            this.btnTruoc = new System.Windows.Forms.Button();
            this.lblTienDo = new System.Windows.Forms.Label();
            this.timerDemNguoc = new System.Windows.Forms.Timer(this.components);
            this.cboChonDe = new System.Windows.Forms.ComboBox();
            this.pnlTop.SuspendLayout();
            this.pnlCard.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picMinhHoa)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(225)))), ((int)(((byte)(238)))));
            this.pnlTop.Controls.Add(this.cboChonDe);
            this.pnlTop.Controls.Add(this.lblDongHo);
            this.pnlTop.Controls.Add(this.lblTieuDeForm);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(860, 50);
            this.pnlTop.TabIndex = 0;
            // 
            // cboChonDe
            // 
            this.cboChonDe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboChonDe.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboChonDe.FormattingEnabled = true;
            this.cboChonDe.Location = new System.Drawing.Point(160, 10);
            this.cboChonDe.Name = "cboChonDe";
            this.cboChonDe.Size = new System.Drawing.Size(320, 29);
            this.cboChonDe.TabIndex = 2;
            this.cboChonDe.SelectedIndexChanged += new System.EventHandler(this.cboChonDe_SelectedIndexChanged);
            // 
            // lblDongHo
            // 
            this.lblDongHo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDongHo.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDongHo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(50)))), ((int)(((byte)(110)))));
            this.lblDongHo.Location = new System.Drawing.Point(580, 5);
            this.lblDongHo.Name = "lblDongHo";
            this.lblDongHo.Size = new System.Drawing.Size(260, 40);
            this.lblDongHo.TabIndex = 1;
            this.lblDongHo.Text = "⏱ 00:45:00";
            this.lblDongHo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTieuDeForm
            // 
            this.lblTieuDeForm.AutoSize = true;
            this.lblTieuDeForm.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDeForm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(40)))), ((int)(((byte)(100)))));
            this.lblTieuDeForm.Location = new System.Drawing.Point(18, 9);
            this.lblTieuDeForm.Name = "lblTieuDeForm";
            this.lblTieuDeForm.Size = new System.Drawing.Size(133, 31);
            this.lblTieuDeForm.TabIndex = 0;
            this.lblTieuDeForm.Text = "📝 Làm bài thi";
            // 
            // pnlCard
            // 
            this.pnlCard.BackColor = System.Drawing.Color.White;
            this.pnlCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCard.Controls.Add(this.picMinhHoa);
            this.pnlCard.Controls.Add(this.rdoD);
            this.pnlCard.Controls.Add(this.rdoC);
            this.pnlCard.Controls.Add(this.rdoB);
            this.pnlCard.Controls.Add(this.rdoA);
            this.pnlCard.Controls.Add(this.lblNoiDungCauHoi);
            this.pnlCard.Location = new System.Drawing.Point(24, 65);
            this.pnlCard.Name = "pnlCard";
            this.pnlCard.Size = new System.Drawing.Size(810, 260);
            this.pnlCard.TabIndex = 1;
            // 
            // picMinhHoa
            // 
            this.picMinhHoa.Image = global::dethitracnghiem.Properties.Resources.anh;
            this.picMinhHoa.Location = new System.Drawing.Point(620, 25);
            this.picMinhHoa.Name = "picMinhHoa";
            this.picMinhHoa.Size = new System.Drawing.Size(165, 195);
            this.picMinhHoa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picMinhHoa.TabIndex = 5;
            this.picMinhHoa.TabStop = false;
            // 
            // rdoD
            // 
            this.rdoD.AutoSize = true;
            this.rdoD.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoD.Location = new System.Drawing.Point(25, 205);
            this.rdoD.Name = "rdoD";
            this.rdoD.Size = new System.Drawing.Size(117, 27);
            this.rdoD.TabIndex = 4;
            this.rdoD.TabStop = true;
            this.rdoD.Text = "D. Đáp án D";
            this.rdoD.UseVisualStyleBackColor = true;
            this.rdoD.CheckedChanged += new System.EventHandler(this.rdo_CheckedChanged);
            // 
            // rdoC
            // 
            this.rdoC.AutoSize = true;
            this.rdoC.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoC.Location = new System.Drawing.Point(25, 165);
            this.rdoC.Name = "rdoC";
            this.rdoC.Size = new System.Drawing.Size(116, 27);
            this.rdoC.TabIndex = 3;
            this.rdoC.TabStop = true;
            this.rdoC.Text = "C. Đáp án C";
            this.rdoC.UseVisualStyleBackColor = true;
            this.rdoC.CheckedChanged += new System.EventHandler(this.rdo_CheckedChanged);
            // 
            // rdoB
            // 
            this.rdoB.AutoSize = true;
            this.rdoB.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoB.Location = new System.Drawing.Point(25, 125);
            this.rdoB.Name = "rdoB";
            this.rdoB.Size = new System.Drawing.Size(115, 27);
            this.rdoB.TabIndex = 2;
            this.rdoB.TabStop = true;
            this.rdoB.Text = "B. Đáp án B";
            this.rdoB.UseVisualStyleBackColor = true;
            this.rdoB.CheckedChanged += new System.EventHandler(this.rdo_CheckedChanged);
            // 
            // rdoA
            // 
            this.rdoA.AutoSize = true;
            this.rdoA.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoA.Location = new System.Drawing.Point(25, 85);
            this.rdoA.Name = "rdoA";
            this.rdoA.Size = new System.Drawing.Size(117, 27);
            this.rdoA.TabIndex = 1;
            this.rdoA.TabStop = true;
            this.rdoA.Text = "A. Đáp án A";
            this.rdoA.UseVisualStyleBackColor = true;
            this.rdoA.CheckedChanged += new System.EventHandler(this.rdo_CheckedChanged);
            // 
            // lblNoiDungCauHoi
            // 
            this.lblNoiDungCauHoi.Font = new System.Drawing.Font("Segoe UI", 11.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoiDungCauHoi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lblNoiDungCauHoi.Location = new System.Drawing.Point(20, 15);
            this.lblNoiDungCauHoi.Name = "lblNoiDungCauHoi";
            this.lblNoiDungCauHoi.Size = new System.Drawing.Size(585, 60);
            this.lblNoiDungCauHoi.TabIndex = 0;
            this.lblNoiDungCauHoi.Text = "Câu 1: Đây là câu hỏi mẫu?";
            // 
            // pnlBottom
            // 
            this.pnlBottom.Controls.Add(this.btnNopBai);
            this.pnlBottom.Controls.Add(this.btnTiepTheo);
            this.pnlBottom.Controls.Add(this.btnTruoc);
            this.pnlBottom.Controls.Add(this.lblTienDo);
            this.pnlBottom.Location = new System.Drawing.Point(24, 340);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(810, 50);
            this.pnlBottom.TabIndex = 2;
            // 
            // btnNopBai
            // 
            this.btnNopBai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(75)))), ((int)(((byte)(125)))));
            this.btnNopBai.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNopBai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNopBai.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNopBai.ForeColor = System.Drawing.Color.White;
            this.btnNopBai.Location = new System.Drawing.Point(460, 4);
            this.btnNopBai.Name = "btnNopBai";
            this.btnNopBai.Size = new System.Drawing.Size(140, 40);
            this.btnNopBai.TabIndex = 3;
            this.btnNopBai.Text = "✓ Nộp bài";
            this.btnNopBai.UseVisualStyleBackColor = false;
            this.btnNopBai.Click += new System.EventHandler(this.btnNopBai_Click);
            // 
            // btnTiepTheo
            // 
            this.btnTiepTheo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(75)))), ((int)(((byte)(125)))));
            this.btnTiepTheo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTiepTheo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTiepTheo.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTiepTheo.ForeColor = System.Drawing.Color.White;
            this.btnTiepTheo.Location = new System.Drawing.Point(620, 4);
            this.btnTiepTheo.Name = "btnTiepTheo";
            this.btnTiepTheo.Size = new System.Drawing.Size(165, 40);
            this.btnTiepTheo.TabIndex = 2;
            this.btnTiepTheo.Text = "Tiếp theo ➔";
            this.btnTiepTheo.UseVisualStyleBackColor = false;
            this.btnTiepTheo.Click += new System.EventHandler(this.btnTiepTheo_Click);
            // 
            // btnTruoc
            // 
            this.btnTruoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.btnTruoc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTruoc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTruoc.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTruoc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.btnTruoc.Location = new System.Drawing.Point(320, 4);
            this.btnTruoc.Name = "btnTruoc";
            this.btnTruoc.Size = new System.Drawing.Size(120, 40);
            this.btnTruoc.TabIndex = 1;
            this.btnTruoc.Text = "← Trước";
            this.btnTruoc.UseVisualStyleBackColor = false;
            this.btnTruoc.Click += new System.EventHandler(this.btnTruoc_Click);
            // 
            // lblTienDo
            // 
            this.lblTienDo.AutoSize = true;
            this.lblTienDo.Font = new System.Drawing.Font("Segoe UI", 11.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTienDo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.lblTienDo.Location = new System.Drawing.Point(10, 12);
            this.lblTienDo.Name = "lblTienDo";
            this.lblTienDo.Size = new System.Drawing.Size(125, 25);
            this.lblTienDo.TabIndex = 0;
            this.lblTienDo.Text = "Câu: 1 / 20";
            // 
            // timerDemNguoc
            // 
            this.timerDemNguoc.Interval = 1000;
            this.timerDemNguoc.Tick += new System.EventHandler(this.timerDemNguoc_Tick);
            // 
            // FrmThi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(235)))), ((int)(((byte)(245)))));
            this.ClientSize = new System.Drawing.Size(860, 410);
            this.Controls.Add(this.pnlBottom);
            this.Controls.Add(this.pnlCard);
            this.Controls.Add(this.pnlTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmThi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Làm bài thi";
            this.Load += new System.EventHandler(this.FrmThi_Load);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlCard.ResumeLayout(false);
            this.pnlCard.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picMinhHoa)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label lblTieuDeForm;
        private System.Windows.Forms.Label lblDongHo;
        private System.Windows.Forms.Panel pnlCard;
        private System.Windows.Forms.Label lblNoiDungCauHoi;
        private System.Windows.Forms.RadioButton rdoD;
        private System.Windows.Forms.RadioButton rdoC;
        private System.Windows.Forms.RadioButton rdoB;
        private System.Windows.Forms.RadioButton rdoA;
        private System.Windows.Forms.PictureBox picMinhHoa;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Label lblTienDo;
        private System.Windows.Forms.Button btnTruoc;
        private System.Windows.Forms.Button btnTiepTheo;
        private System.Windows.Forms.Button btnNopBai;
        private System.Windows.Forms.Timer timerDemNguoc;
        private System.Windows.Forms.ComboBox cboChonDe;
    }
}
