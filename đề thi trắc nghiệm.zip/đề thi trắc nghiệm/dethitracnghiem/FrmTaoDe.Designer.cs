namespace dethitracnghiem
{
    partial class FrmTaoDe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.grpCauHinh = new System.Windows.Forms.GroupBox();
            this.btnChonTatCa = new System.Windows.Forms.Button();
            this.btnTaoDeThi = new System.Windows.Forms.Button();
            this.btnNhapThuCong = new System.Windows.Forms.Button();
            this.btnTaiFile = new System.Windows.Forms.Button();
            this.nudThoiGian = new System.Windows.Forms.NumericUpDown();
            this.nudSoCau = new System.Windows.Forms.NumericUpDown();
            this.cboMonHoc = new System.Windows.Forms.ComboBox();
            this.lblPhut = new System.Windows.Forms.Label();
            this.lblThoiGian = new System.Windows.Forms.Label();
            this.lblSoCau = new System.Windows.Forms.Label();
            this.lblChonMon = new System.Windows.Forms.Label();
            this.grpDanhSachCauHoi = new System.Windows.Forms.GroupBox();
            this.clbDanhSachCauHoi = new System.Windows.Forms.CheckedListBox();
            this.grpCauHinh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudThoiGian)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSoCau)).BeginInit();
            this.grpDanhSachCauHoi.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpCauHinh
            // 
            this.grpCauHinh.Controls.Add(this.btnChonTatCa);
            this.grpCauHinh.Controls.Add(this.btnTaoDeThi);
            this.grpCauHinh.Controls.Add(this.btnNhapThuCong);
            this.grpCauHinh.Controls.Add(this.btnTaiFile);
            this.grpCauHinh.Controls.Add(this.nudThoiGian);
            this.grpCauHinh.Controls.Add(this.nudSoCau);
            this.grpCauHinh.Controls.Add(this.cboMonHoc);
            this.grpCauHinh.Controls.Add(this.lblPhut);
            this.grpCauHinh.Controls.Add(this.lblThoiGian);
            this.grpCauHinh.Controls.Add(this.lblSoCau);
            this.grpCauHinh.Controls.Add(this.lblChonMon);
            this.grpCauHinh.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpCauHinh.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(30)))), ((int)(((byte)(80)))));
            this.grpCauHinh.Location = new System.Drawing.Point(12, 16);
            this.grpCauHinh.Name = "grpCauHinh";
            this.grpCauHinh.Size = new System.Drawing.Size(295, 385);
            this.grpCauHinh.TabIndex = 0;
            this.grpCauHinh.TabStop = false;
            this.grpCauHinh.Text = "Cấu hình tạo đề thi";
            // 
            // btnChonTatCa
            // 
            this.btnChonTatCa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(235)))));
            this.btnChonTatCa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChonTatCa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChonTatCa.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChonTatCa.Location = new System.Drawing.Point(15, 175);
            this.btnChonTatCa.Name = "btnChonTatCa";
            this.btnChonTatCa.Size = new System.Drawing.Size(265, 32);
            this.btnChonTatCa.TabIndex = 12;
            this.btnChonTatCa.Text = "☑ Chọn tất cả câu hỏi theo số lượng";
            this.btnChonTatCa.UseVisualStyleBackColor = false;
            this.btnChonTatCa.Click += new System.EventHandler(this.btnChonTatCa_Click);
            // 
            // btnTaoDeThi
            // 
            this.btnTaoDeThi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(50)))), ((int)(((byte)(110)))));
            this.btnTaoDeThi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTaoDeThi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTaoDeThi.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTaoDeThi.ForeColor = System.Drawing.Color.White;
            this.btnTaoDeThi.Location = new System.Drawing.Point(15, 305);
            this.btnTaoDeThi.Name = "btnTaoDeThi";
            this.btnTaoDeThi.Size = new System.Drawing.Size(265, 42);
            this.btnTaoDeThi.TabIndex = 11;
            this.btnTaoDeThi.Text = "💾 Lưu & Tạo đề thi mới";
            this.btnTaoDeThi.UseVisualStyleBackColor = false;
            this.btnTaoDeThi.Click += new System.EventHandler(this.btnTaoDeThi_Click);
            // 
            // btnNhapThuCong
            // 
            this.btnNhapThuCong.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(200)))), ((int)(((byte)(220)))));
            this.btnNhapThuCong.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNhapThuCong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNhapThuCong.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhapThuCong.ForeColor = System.Drawing.Color.Black;
            this.btnNhapThuCong.Location = new System.Drawing.Point(150, 225);
            this.btnNhapThuCong.Name = "btnNhapThuCong";
            this.btnNhapThuCong.Size = new System.Drawing.Size(130, 36);
            this.btnNhapThuCong.TabIndex = 10;
            this.btnNhapThuCong.Text = "📝 Thêm câu hỏi";
            this.btnNhapThuCong.UseVisualStyleBackColor = false;
            this.btnNhapThuCong.Click += new System.EventHandler(this.btnNhapThuCong_Click);
            // 
            // btnTaiFile
            // 
            this.btnTaiFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(200)))), ((int)(((byte)(220)))));
            this.btnTaiFile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTaiFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTaiFile.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTaiFile.ForeColor = System.Drawing.Color.Black;
            this.btnTaiFile.Location = new System.Drawing.Point(15, 225);
            this.btnTaiFile.Name = "btnTaiFile";
            this.btnTaiFile.Size = new System.Drawing.Size(125, 36);
            this.btnTaiFile.TabIndex = 9;
            this.btnTaiFile.Text = "📁 Tải file câu hỏi";
            this.btnTaiFile.UseVisualStyleBackColor = false;
            this.btnTaiFile.Click += new System.EventHandler(this.btnTaiFile_Click);
            // 
            // nudThoiGian
            // 
            this.nudThoiGian.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudThoiGian.Location = new System.Drawing.Point(135, 124);
            this.nudThoiGian.Maximum = new decimal(new int[] { 180, 0, 0, 0 });
            this.nudThoiGian.Minimum = new decimal(new int[] { 5, 0, 0, 0 });
            this.nudThoiGian.Name = "nudThoiGian";
            this.nudThoiGian.Size = new System.Drawing.Size(95, 29);
            this.nudThoiGian.TabIndex = 6;
            this.nudThoiGian.Value = new decimal(new int[] { 45, 0, 0, 0 });
            // 
            // nudSoCau
            // 
            this.nudSoCau.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudSoCau.Location = new System.Drawing.Point(135, 84);
            this.nudSoCau.Maximum = new decimal(new int[] { 100, 0, 0, 0 });
            this.nudSoCau.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.nudSoCau.Name = "nudSoCau";
            this.nudSoCau.Size = new System.Drawing.Size(145, 29);
            this.nudSoCau.TabIndex = 5;
            this.nudSoCau.Value = new decimal(new int[] { 20, 0, 0, 0 });
            // 
            // cboMonHoc
            // 
            this.cboMonHoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMonHoc.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboMonHoc.FormattingEnabled = true;
            this.cboMonHoc.Location = new System.Drawing.Point(135, 42);
            this.cboMonHoc.Name = "cboMonHoc";
            this.cboMonHoc.Size = new System.Drawing.Size(145, 29);
            this.cboMonHoc.TabIndex = 4;
            this.cboMonHoc.SelectedIndexChanged += new System.EventHandler(this.cboMonHoc_SelectedIndexChanged);
            // 
            // lblPhut
            // 
            this.lblPhut.AutoSize = true;
            this.lblPhut.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhut.Location = new System.Drawing.Point(235, 126);
            this.lblPhut.Name = "lblPhut";
            this.lblPhut.Size = new System.Drawing.Size(42, 21);
            this.lblPhut.TabIndex = 3;
            this.lblPhut.Text = "phút";
            // 
            // lblThoiGian
            // 
            this.lblThoiGian.AutoSize = true;
            this.lblThoiGian.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThoiGian.Location = new System.Drawing.Point(10, 126);
            this.lblThoiGian.Name = "lblThoiGian";
            this.lblThoiGian.Size = new System.Drawing.Size(126, 21);
            this.lblThoiGian.TabIndex = 2;
            this.lblThoiGian.Text = "Thời gian làm bài:";
            // 
            // lblSoCau
            // 
            this.lblSoCau.AutoSize = true;
            this.lblSoCau.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoCau.Location = new System.Drawing.Point(10, 86);
            this.lblSoCau.Name = "lblSoCau";
            this.lblSoCau.Size = new System.Drawing.Size(84, 21);
            this.lblSoCau.TabIndex = 1;
            this.lblSoCau.Text = "Số câu hỏi:";
            // 
            // lblChonMon
            // 
            this.lblChonMon.AutoSize = true;
            this.lblChonMon.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChonMon.Location = new System.Drawing.Point(10, 45);
            this.lblChonMon.Name = "lblChonMon";
            this.lblChonMon.Size = new System.Drawing.Size(113, 21);
            this.lblChonMon.TabIndex = 0;
            this.lblChonMon.Text = "Chọn môn học:";
            // 
            // grpDanhSachCauHoi
            // 
            this.grpDanhSachCauHoi.Controls.Add(this.clbDanhSachCauHoi);
            this.grpDanhSachCauHoi.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpDanhSachCauHoi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(30)))), ((int)(((byte)(80)))));
            this.grpDanhSachCauHoi.Location = new System.Drawing.Point(315, 16);
            this.grpDanhSachCauHoi.Name = "grpDanhSachCauHoi";
            this.grpDanhSachCauHoi.Size = new System.Drawing.Size(515, 385);
            this.grpDanhSachCauHoi.TabIndex = 1;
            this.grpDanhSachCauHoi.TabStop = false;
            this.grpDanhSachCauHoi.Text = "Danh sách câu hỏi môn thi";
            // 
            // clbDanhSachCauHoi
            // 
            this.clbDanhSachCauHoi.CheckOnClick = true;
            this.clbDanhSachCauHoi.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbDanhSachCauHoi.FormattingEnabled = true;
            this.clbDanhSachCauHoi.Location = new System.Drawing.Point(15, 28);
            this.clbDanhSachCauHoi.Name = "clbDanhSachCauHoi";
            this.clbDanhSachCauHoi.Size = new System.Drawing.Size(485, 340);
            this.clbDanhSachCauHoi.TabIndex = 0;
            // 
            // FrmTaoDe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(235)))), ((int)(((byte)(245)))));
            this.ClientSize = new System.Drawing.Size(845, 415);
            this.Controls.Add(this.grpDanhSachCauHoi);
            this.Controls.Add(this.grpCauHinh);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmTaoDe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tạo đề thi";
            this.Load += new System.EventHandler(this.FrmTaoDe_Load);
            this.grpCauHinh.ResumeLayout(false);
            this.grpCauHinh.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudThoiGian)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSoCau)).EndInit();
            this.grpDanhSachCauHoi.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpCauHinh;
        private System.Windows.Forms.Label lblPhut;
        private System.Windows.Forms.Label lblThoiGian;
        private System.Windows.Forms.Label lblSoCau;
        private System.Windows.Forms.Label lblChonMon;
        private System.Windows.Forms.Button btnTaiFile;
        private System.Windows.Forms.NumericUpDown nudThoiGian;
        private System.Windows.Forms.NumericUpDown nudSoCau;
        private System.Windows.Forms.ComboBox cboMonHoc;
        private System.Windows.Forms.GroupBox grpDanhSachCauHoi;
        private System.Windows.Forms.Button btnNhapThuCong;
        private System.Windows.Forms.CheckedListBox clbDanhSachCauHoi;
        private System.Windows.Forms.Button btnTaoDeThi;
        private System.Windows.Forms.Button btnChonTatCa;
    }
}
