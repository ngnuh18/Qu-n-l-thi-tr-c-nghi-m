using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace dethitracnghiem
{
    public class TaiKhoan
    {
        public string TenDangNhap { get; set; }
        public string MatKhau { get; set; }
        public string VaiTro { get; set; } // "Sinh viên" hoặc "Quản trị viên"
        public string MSSV { get; set; }
        public string HoTen { get; set; }
        public string Lop { get; set; }

        public TaiKhoan() { }
        public TaiKhoan(string tenDangNhap, string matKhau, string vaiTro, string mssv, string hoTen, string lop)
        {
            TenDangNhap = tenDangNhap;
            MatKhau = matKhau;
            VaiTro = vaiTro;
            MSSV = mssv;
            HoTen = hoTen;
            Lop = lop;
        }
    }

    public class SinhVien
    {
        public string MSSV { get; set; }
        public string HoTen { get; set; }
        public string Lop { get; set; }
        public int SoDe { get; set; }

        public SinhVien() { }
        public SinhVien(string mssv, string hoTen, string lop, int soDe)
        {
            MSSV = mssv;
            HoTen = hoTen;
            Lop = lop;
            SoDe = soDe;
        }
    }

    public class MonHoc
    {
        public string MaMon { get; set; }
        public string TenMon { get; set; }
        public int SoTinChi { get; set; }
        public string GhiChu { get; set; }

        public MonHoc() { }
        public MonHoc(string maMon, string tenMon, int soTinChi, string ghiChu)
        {
            MaMon = maMon;
            TenMon = tenMon;
            SoTinChi = soTinChi;
            GhiChu = ghiChu;
        }
    }

    public class CauHoi
    {
        public int Id { get; set; }
        public string MaMon { get; set; }
        public string NoiDung { get; set; }
        public string DapAnA { get; set; }
        public string DapAnB { get; set; }
        public string DapAnC { get; set; }
        public string DapAnD { get; set; }
        public string DapAnDung { get; set; } // "A", "B", "C", "D"

        public CauHoi() { }
        public CauHoi(int id, string maMon, string noiDung, string a, string b, string c, string d, string dung)
        {
            Id = id;
            MaMon = maMon;
            NoiDung = noiDung;
            DapAnA = a;
            DapAnB = b;
            DapAnC = c;
            DapAnD = d;
            DapAnDung = dung;
        }
    }

    public class DeThi
    {
        public string MaDe { get; set; }
        public string TenDe { get; set; }
        public string MaMon { get; set; }
        public string TenMon { get; set; }
        public int SoCau { get; set; }
        public int ThoiGianPhut { get; set; }
        public List<CauHoi> DanhSachCauHoi { get; set; } = new List<CauHoi>();
    }

    public class ChiTietCauTraLoi
    {
        public CauHoi CauHoi { get; set; }
        public string DapAnChon { get; set; }
        public string DapAnDung { get; set; }
        public bool LaDung => string.Equals(DapAnChon, DapAnDung, StringComparison.OrdinalIgnoreCase);
    }

    public class KetQuaThi
    {
        public string MSSV { get; set; }
        public string HoTen { get; set; }
        public string TenMon { get; set; }
        public double Diem { get; set; }
        public string XepLoai { get; set; }
        public DateTime ThoiGian { get; set; }
        public int SoCauDung { get; set; }
        public int TongSoCau { get; set; }
        public List<ChiTietCauTraLoi> ChiTiet { get; set; } = new List<ChiTietCauTraLoi>();
    }

    public static class DataStore
    {
        public static string NguoiDungHienTai { get; set; } = "";
        public static string HoTenHienTai { get; set; } = "";
        public static string VaiTroHienTai { get; set; } = "";
        public static string MSSVHienTai { get; set; } = "";
        public static string LopHienTai { get; set; } = "";

        public static List<TaiKhoan> DanhSachTaiKhoan { get; set; } = new List<TaiKhoan>();
        public static List<SinhVien> DanhSachSinhVien { get; set; } = new List<SinhVien>();
        public static List<MonHoc> DanhSachMonHoc { get; set; } = new List<MonHoc>();
        public static List<CauHoi> DanhSachCauHoi { get; set; } = new List<CauHoi>();
        public static List<DeThi> DanhSachDeThi { get; set; } = new List<DeThi>();
        public static List<KetQuaThi> DanhSachKetQua { get; set; } = new List<KetQuaThi>();
        public static KetQuaThi KetQuaMoiNhat { get; set; } = null;

        public static event Action DataChanged;

        public static void NotifyDataChanged()
        {
            DataChanged?.Invoke();
        }

        static DataStore()
        {
            KhoiTaoDuLieuMacDinh();
        }

        public static void KhoiTaoDuLieuMacDinh()
        {
            // Xóa hết dữ liệu mẫu theo yêu cầu người dùng
            DanhSachSinhVien = new List<SinhVien>();
            DanhSachMonHoc = new List<MonHoc>();
            DanhSachCauHoi = new List<CauHoi>();
            DanhSachDeThi = new List<DeThi>();
            DanhSachKetQua = new List<KetQuaThi>();
            KetQuaMoiNhat = null;

            // Tài khoản admin giữ nguyên theo yêu cầu: admin / 123
            DanhSachTaiKhoan = new List<TaiKhoan>
            {
                new TaiKhoan("admin", "123", "Quản trị viên", "ADMIN", "Quản trị viên hệ thống", "Ban quản trị")
            };
        }

        // Đăng ký tài khoản sinh viên mới
        public static bool DangKySinhVien(string tenDangNhap, string matKhau, string mssv, string hoTen, string lop, out string thongBaoLoi)
        {
            thongBaoLoi = "";

            if (string.IsNullOrWhiteSpace(tenDangNhap) || string.IsNullOrWhiteSpace(matKhau))
            {
                thongBaoLoi = "Tên đăng nhập và mật khẩu không được để trống!";
                return false;
            }

            if (string.IsNullOrWhiteSpace(mssv) || string.IsNullOrWhiteSpace(hoTen))
            {
                thongBaoLoi = "Mã sinh viên và họ tên không được để trống!";
                return false;
            }

            // Kiểm tra trùng tên đăng nhập hoặc trùng với admin
            if (tenDangNhap.Equals("admin", StringComparison.OrdinalIgnoreCase) ||
                DanhSachTaiKhoan.Any(t => t.TenDangNhap.Equals(tenDangNhap, StringComparison.OrdinalIgnoreCase)))
            {
                thongBaoLoi = "Tên đăng nhập đã được sử dụng! Vui lòng chọn tên khác.";
                return false;
            }

            // Kiểm tra trùng MSSV
            if (DanhSachSinhVien.Any(s => s.MSSV.Equals(mssv, StringComparison.OrdinalIgnoreCase)))
            {
                thongBaoLoi = "Mã số sinh viên này đã tồn tại trong hệ thống!";
                return false;
            }

            // Tạo tài khoản và thêm sinh viên vào danh sách
            TaiKhoan tk = new TaiKhoan(tenDangNhap, matKhau, "Sinh viên", mssv, hoTen, lop);
            DanhSachTaiKhoan.Add(tk);

            SinhVien sv = new SinhVien(mssv, hoTen, lop, 0);
            DanhSachSinhVien.Add(sv);

            NotifyDataChanged();
            return true;
        }

        // Đọc danh sách sinh viên từ file Excel (.xlsx, .xls) hoặc CSV/TXT
        public static int DocSinhVienTuFile(string filePath)
        {
            var rows = ExcelHelper.DocTatCaCacDong(filePath);
            if (rows.Count == 0) return 0;

            int dem = 0;

            // 1. Phân tích tiêu đề cột nếu có
            int colMSSV = -1;
            int colHoTen = -1;
            int colLop = -1;
            int colSoDe = -1;
            int colMatKhau = -1;
            int startRow = 0;

            // Kiểm tra các dòng đầu để nhận diện dòng tiêu đề
            for (int r = 0; r < Math.Min(3, rows.Count); r++)
            {
                var rList = rows[r];
                for (int c = 0; c < rList.Count; c++)
                {
                    string h = rList[c].Trim().ToLower();
                    if (colMSSV < 0 && (h.Contains("mssv") || h.Contains("mã sv") || h.Contains("mã sinh viên") || h.Equals("masv") || h.Equals("id")))
                        colMSSV = c;
                    else if (colHoTen < 0 && (h.Contains("họ tên") || h.Contains("họ và tên") || h.Contains("tên") || h.Equals("hoten") || h.Equals("name")))
                        colHoTen = c;
                    else if (colLop < 0 && (h.Contains("lớp") || h.Equals("lop") || h.Equals("class")))
                        colLop = c;
                    else if (colSoDe < 0 && (h.Contains("số đề") || h.Equals("sode") || h.Contains("đề thi")))
                        colSoDe = c;
                    else if (colMatKhau < 0 && (h.Contains("mật khẩu") || h.Equals("matkhau") || h.Equals("password") || h.Equals("pass")))
                        colMatKhau = c;
                }

                if (colMSSV >= 0 || colHoTen >= 0)
                {
                    startRow = r + 1;
                    break;
                }
            }

            // Nếu không phát hiện dòng tiêu đề, kiểm tra xem cột 0 có phải là STT không
            if (colMSSV < 0 || colHoTen < 0)
            {
                startRow = 0;
                var firstRow = rows[0];

                if (firstRow.Count > 0 && (firstRow[0].Equals("STT", StringComparison.OrdinalIgnoreCase) ||
                                           firstRow[0].Equals("MSSV", StringComparison.OrdinalIgnoreCase) ||
                                           firstRow[0].Equals("Mã SV", StringComparison.OrdinalIgnoreCase)))
                {
                    startRow = 1;
                }

                int checkRow = startRow < rows.Count ? startRow : 0;
                if (rows[checkRow].Count >= 3 && int.TryParse(rows[checkRow][0].Trim(), out _))
                {
                    // Cột 0 là STT: [STT, MSSV, HoTen, Lop, SoDe, MatKhau]
                    colMSSV = 1;
                    colHoTen = 2;
                    colLop = 3;
                    colSoDe = 4;
                    colMatKhau = 5;
                }
                else
                {
                    // [MSSV, HoTen, Lop, SoDe, MatKhau]
                    colMSSV = 0;
                    colHoTen = 1;
                    colLop = 2;
                    colSoDe = 3;
                    colMatKhau = 4;
                }
            }

            for (int i = startRow; i < rows.Count; i++)
            {
                var row = rows[i];
                if (row.Count == 0) continue;

                string mssv = (colMSSV >= 0 && colMSSV < row.Count) ? row[colMSSV].Trim() : "";
                string hoTen = (colHoTen >= 0 && colHoTen < row.Count) ? row[colHoTen].Trim() : "";
                string lop = (colLop >= 0 && colLop < row.Count) ? row[colLop].Trim() : "";

                if (string.IsNullOrWhiteSpace(mssv) || string.IsNullOrWhiteSpace(hoTen))
                    continue;

                if (mssv.Equals("MSSV", StringComparison.OrdinalIgnoreCase) ||
                    mssv.Equals("Mã SV", StringComparison.OrdinalIgnoreCase) ||
                    mssv.Equals("MaSV", StringComparison.OrdinalIgnoreCase) ||
                    mssv.Equals("STT", StringComparison.OrdinalIgnoreCase))
                    continue;

                int soDe = 0;
                if (colSoDe >= 0 && colSoDe < row.Count)
                {
                    int.TryParse(row[colSoDe].Trim(), out soDe);
                }

                string matKhau = "123";
                if (colMatKhau >= 0 && colMatKhau < row.Count && !string.IsNullOrWhiteSpace(row[colMatKhau]))
                {
                    matKhau = row[colMatKhau].Trim();
                }

                var sv = DanhSachSinhVien.FirstOrDefault(s => s.MSSV.Equals(mssv, StringComparison.OrdinalIgnoreCase));
                if (sv != null)
                {
                    sv.HoTen = hoTen;
                    if (!string.IsNullOrEmpty(lop)) sv.Lop = lop;
                    if (soDe > 0) sv.SoDe = soDe;
                }
                else
                {
                    DanhSachSinhVien.Add(new SinhVien(mssv, hoTen, lop, soDe));
                }

                // Tự động tạo / cập nhật tài khoản đăng nhập cho sinh viên
                var tk = DanhSachTaiKhoan.FirstOrDefault(t => t.MSSV.Equals(mssv, StringComparison.OrdinalIgnoreCase) || t.TenDangNhap.Equals(mssv, StringComparison.OrdinalIgnoreCase));
                if (tk == null)
                {
                    DanhSachTaiKhoan.Add(new TaiKhoan(mssv, matKhau, "Sinh viên", mssv, hoTen, lop));
                }
                else
                {
                    tk.HoTen = hoTen;
                    if (!string.IsNullOrEmpty(lop)) tk.Lop = lop;
                    if (!string.IsNullOrEmpty(matKhau) && matKhau != "123") tk.MatKhau = matKhau;
                }

                dem++;
            }

            NotifyDataChanged();
            return dem;
        }

        // Đọc danh sách môn học từ file Excel (.xlsx, .xls) hoặc CSV/TXT
        public static int DocMonHocTuFile(string filePath)
        {
            var rows = ExcelHelper.DocTatCaCacDong(filePath);
            if (rows.Count == 0) return 0;

            int dem = 0;
            int colMa = -1, colTen = -1, colTinChi = -1, colGhiChu = -1;
            int startRow = 0;

            for (int r = 0; r < Math.Min(3, rows.Count); r++)
            {
                var rList = rows[r];
                for (int c = 0; c < rList.Count; c++)
                {
                    string h = rList[c].Trim().ToLower();
                    if (colMa < 0 && (h.Contains("mã môn") || h.Contains("mamon") || h.Contains("mã mh"))) colMa = c;
                    else if (colTen < 0 && (h.Contains("tên môn") || h.Contains("tenmon") || h.Contains("tên mh"))) colTen = c;
                    else if (colTinChi < 0 && (h.Contains("tín chỉ") || h.Contains("tinchi") || h.Contains("stc"))) colTinChi = c;
                    else if (colGhiChu < 0 && (h.Contains("ghi chú") || h.Contains("ghichu") || h.Contains("mô tả"))) colGhiChu = c;
                }
                if (colMa >= 0 || colTen >= 0)
                {
                    startRow = r + 1;
                    break;
                }
            }

            if (colMa < 0 || colTen < 0)
            {
                startRow = 0;
                if (rows[0].Count > 0 && rows[0][0].Equals("MaMon", StringComparison.OrdinalIgnoreCase)) startRow = 1;
                colMa = 0;
                colTen = 1;
                colTinChi = 2;
                colGhiChu = 3;
            }

            for (int i = startRow; i < rows.Count; i++)
            {
                var row = rows[i];
                if (row.Count == 0) continue;

                string ma = (colMa >= 0 && colMa < row.Count) ? row[colMa].Trim() : "";
                string ten = (colTen >= 0 && colTen < row.Count) ? row[colTen].Trim() : "";
                if (string.IsNullOrWhiteSpace(ma) || string.IsNullOrWhiteSpace(ten)) continue;
                if (ma.Equals("MaMon", StringComparison.OrdinalIgnoreCase) || ma.Equals("Mã môn", StringComparison.OrdinalIgnoreCase)) continue;

                int tinChi = 3;
                if (colTinChi >= 0 && colTinChi < row.Count) int.TryParse(row[colTinChi].Trim(), out tinChi);
                if (tinChi <= 0) tinChi = 3;

                string ghiChu = (colGhiChu >= 0 && colGhiChu < row.Count) ? row[colGhiChu].Trim() : "";

                var mh = DanhSachMonHoc.FirstOrDefault(m => m.MaMon.Equals(ma, StringComparison.OrdinalIgnoreCase));
                if (mh != null)
                {
                    mh.TenMon = ten;
                    mh.SoTinChi = tinChi;
                    mh.GhiChu = ghiChu;
                }
                else
                {
                    DanhSachMonHoc.Add(new MonHoc(ma, ten, tinChi, ghiChu));
                }
                dem++;
            }
            NotifyDataChanged();
            return dem;
        }

        // Đọc câu hỏi từ file Excel (.xlsx, .xls) hoặc text/csv
        public static int DocCauHoiTuFile(string filePath, string maMonMacDinh = "")
        {
            var rows = ExcelHelper.DocTatCaCacDong(filePath);
            if (rows.Count == 0) return 0;

            int dem = 0;
            int startRow = 0;

            if (rows[0].Count > 0)
            {
                string first = rows[0][0].Trim().ToLower();
                if (first.Contains("câu hỏi") || first.Contains("noidung") || first.Contains("mamon") || first.Contains("mã môn"))
                {
                    startRow = 1;
                }
            }

            for (int i = startRow; i < rows.Count; i++)
            {
                var parts = rows[i];
                if (parts.Count < 5) continue;

                string maMon = maMonMacDinh;
                string noiDung;
                string daA, daB, daC, daD;
                string daDung = "A";

                if (parts.Count >= 7)
                {
                    maMon = parts[0].Trim();
                    noiDung = parts[1].Trim();
                    daA = parts[2].Trim();
                    daB = parts[3].Trim();
                    daC = parts[4].Trim();
                    daD = parts[5].Trim();
                    daDung = parts[6].Trim().ToUpper();
                }
                else
                {
                    noiDung = parts[0].Trim();
                    daA = parts[1].Trim();
                    daB = parts[2].Trim();
                    daC = parts[3].Trim();
                    daD = parts.Count >= 5 ? parts[4].Trim() : "";
                    if (parts.Count >= 6) daDung = parts[5].Trim().ToUpper();
                }

                if (string.IsNullOrWhiteSpace(noiDung)) continue;

                if (string.IsNullOrEmpty(maMon))
                {
                    if (DanhSachMonHoc.Count > 0)
                        maMon = DanhSachMonHoc[0].MaMon;
                    else
                        maMon = "MH01";
                }

                if (!DanhSachMonHoc.Any(m => m.MaMon.Equals(maMon, StringComparison.OrdinalIgnoreCase)))
                {
                    DanhSachMonHoc.Add(new MonHoc(maMon, "Môn học " + maMon, 3, "Tự động tạo khi tải câu hỏi"));
                }

                int nextId = DanhSachCauHoi.Count > 0 ? DanhSachCauHoi.Max(c => c.Id) + 1 : 1;
                DanhSachCauHoi.Add(new CauHoi(nextId, maMon, noiDung, daA, daB, daC, daD, daDung));
                dem++;
            }
            NotifyDataChanged();
            return dem;
        }

        // Đọc đề thi từ file hoặc tạo đề từ câu hỏi trong file
        public static int DocDeThiTuFile(string filePath, string tenMon = "", int thoiGianPhut = 45)
        {
            int demCauHoi = DocCauHoiTuFile(filePath);
            if (demCauHoi > 0)
            {
                string maMon = DanhSachMonHoc.Count > 0 ? DanhSachMonHoc[0].MaMon : "MH01";
                string tMon = !string.IsNullOrEmpty(tenMon) ? tenMon : (DanhSachMonHoc.Count > 0 ? DanhSachMonHoc[0].TenMon : "Môn thi trắc nghiệm");
                string maDe = "DT" + (DanhSachDeThi.Count + 1).ToString("D2");
                string tenDe = "Đề thi " + tMon + " - Mã " + maDe;

                var cauHoiMoi = DanhSachCauHoi.Skip(Math.Max(0, DanhSachCauHoi.Count - demCauHoi)).ToList();
                DeThi dt = new DeThi
                {
                    MaDe = maDe,
                    TenDe = tenDe,
                    MaMon = maMon,
                    TenMon = tMon,
                    SoCau = cauHoiMoi.Count,
                    ThoiGianPhut = thoiGianPhut,
                    DanhSachCauHoi = cauHoiMoi
                };
                DanhSachDeThi.Add(dt);
                NotifyDataChanged();
                return 1;
            }
            return 0;
        }
    }
}
