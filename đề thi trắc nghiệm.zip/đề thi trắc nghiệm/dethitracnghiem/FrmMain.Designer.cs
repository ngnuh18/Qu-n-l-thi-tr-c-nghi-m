﻿namespace dethitracnghiem
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sinhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mônHọcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ngânHàngCâuHỏiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thiCửToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tạoĐềThiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tổChứcThiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giámSátThiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xemBáoCáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thốngKêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.pnlMenu = new System.Windows.Forms.Panel();
            this.btnGiamSatThi = new System.Windows.Forms.Button();
            this.btnDangXuat = new System.Windows.Forms.Button();
            this.btnKetQua = new System.Windows.Forms.Button();
            this.btnToChucThi = new System.Windows.Forms.Button();
            this.btnTaoDe = new System.Windows.Forms.Button();
            this.btnCauHoi = new System.Windows.Forms.Button();
            this.btnMonHoc = new System.Windows.Forms.Button();
            this.btnSinhVien = new System.Windows.Forms.Button();
            this.btnTrangChu = new System.Windows.Forms.Button();
            this.lblLogo = new System.Windows.Forms.Label();
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblMoTa = new System.Windows.Forms.Label();
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.pnlNoiDung = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.pnlMenu.SuspendLayout();
            this.pnlHeader.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hệThốngToolStripMenuItem,
            this.quảnLýToolStripMenuItem,
            this.thiCửToolStripMenuItem,
            this.báoCáoToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1625, 30);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hệThốngToolStripMenuItem
            // 
            this.hệThốngToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.hệThốngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.đăngXuấtToolStripMenuItem,
            this.thoátToolStripMenuItem});
            this.hệThốngToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(35)))), ((int)(((byte)(80)))));
            this.hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            this.hệThốngToolStripMenuItem.Size = new System.Drawing.Size(85, 26);
            this.hệThốngToolStripMenuItem.Text = "Hệ thống";
            // 
            // đăngXuấtToolStripMenuItem
            // 
            this.đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            this.đăngXuấtToolStripMenuItem.Size = new System.Drawing.Size(160, 26);
            this.đăngXuấtToolStripMenuItem.Text = "Đăng xuất";
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(160, 26);
            this.thoátToolStripMenuItem.Text = "Thoát";
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.quảnLýToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sinhViênToolStripMenuItem,
            this.mônHọcToolStripMenuItem,
            this.ngânHàngCâuHỏiToolStripMenuItem});
            this.quảnLýToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(35)))), ((int)(((byte)(80)))));
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(73, 26);
            this.quảnLýToolStripMenuItem.Text = "Quản lý";
            // 
            // sinhViênToolStripMenuItem
            // 
            this.sinhViênToolStripMenuItem.Name = "sinhViênToolStripMenuItem";
            this.sinhViênToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
            this.sinhViênToolStripMenuItem.Text = "Sinh viên";
            // 
            // mônHọcToolStripMenuItem
            // 
            this.mônHọcToolStripMenuItem.Name = "mônHọcToolStripMenuItem";
            this.mônHọcToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
            this.mônHọcToolStripMenuItem.Text = "Môn học";
            // 
            // ngânHàngCâuHỏiToolStripMenuItem
            // 
            this.ngânHàngCâuHỏiToolStripMenuItem.Name = "ngânHàngCâuHỏiToolStripMenuItem";
            this.ngânHàngCâuHỏiToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
            this.ngânHàngCâuHỏiToolStripMenuItem.Text = "Ngân hàng câu hỏi";
            // 
            // thiCửToolStripMenuItem
            // 
            this.thiCửToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.thiCửToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tạoĐềThiToolStripMenuItem,
            this.tổChứcThiToolStripMenuItem,
            this.giámSátThiToolStripMenuItem});
            this.thiCửToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(35)))), ((int)(((byte)(80)))));
            this.thiCửToolStripMenuItem.Name = "thiCửToolStripMenuItem";
            this.thiCửToolStripMenuItem.Size = new System.Drawing.Size(63, 26);
            this.thiCửToolStripMenuItem.Text = "Thi cử";
            // 
            // tạoĐềThiToolStripMenuItem
            // 
            this.tạoĐềThiToolStripMenuItem.Name = "tạoĐềThiToolStripMenuItem";
            this.tạoĐềThiToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.tạoĐềThiToolStripMenuItem.Text = "Tạo đề thi";
            // 
            // tổChứcThiToolStripMenuItem
            // 
            this.tổChứcThiToolStripMenuItem.Name = "tổChứcThiToolStripMenuItem";
            this.tổChứcThiToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.tổChứcThiToolStripMenuItem.Text = "Tổ chức thi";
            // 
            // giámSátThiToolStripMenuItem
            // 
            this.giámSátThiToolStripMenuItem.Name = "giámSátThiToolStripMenuItem";
            this.giámSátThiToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.giámSátThiToolStripMenuItem.Text = "Giám sát thi ";
            // 
            // báoCáoToolStripMenuItem
            // 
            this.báoCáoToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.báoCáoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xemBáoCáoToolStripMenuItem,
            this.thốngKêToolStripMenuItem});
            this.báoCáoToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(35)))), ((int)(((byte)(80)))));
            this.báoCáoToolStripMenuItem.Name = "báoCáoToolStripMenuItem";
            this.báoCáoToolStripMenuItem.Size = new System.Drawing.Size(77, 26);
            this.báoCáoToolStripMenuItem.Text = "Báo cáo";
            // 
            // xemBáoCáoToolStripMenuItem
            // 
            this.xemBáoCáoToolStripMenuItem.Name = "xemBáoCáoToolStripMenuItem";
            this.xemBáoCáoToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.xemBáoCáoToolStripMenuItem.Text = "Xem kết quả";
            // 
            // thốngKêToolStripMenuItem
            // 
            this.thốngKêToolStripMenuItem.Name = "thốngKêToolStripMenuItem";
            this.thốngKêToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.thốngKêToolStripMenuItem.Text = "Thống kê";
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.trợGiúpToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(35)))), ((int)(((byte)(80)))));
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(78, 26);
            this.trợGiúpToolStripMenuItem.Text = "Trợ giúp";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // pnlMenu
            // 
            this.pnlMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(225)))), ((int)(((byte)(238)))));
            this.pnlMenu.Controls.Add(this.btnGiamSatThi);
            this.pnlMenu.Controls.Add(this.btnDangXuat);
            this.pnlMenu.Controls.Add(this.btnKetQua);
            this.pnlMenu.Controls.Add(this.btnToChucThi);
            this.pnlMenu.Controls.Add(this.btnTaoDe);
            this.pnlMenu.Controls.Add(this.btnCauHoi);
            this.pnlMenu.Controls.Add(this.btnMonHoc);
            this.pnlMenu.Controls.Add(this.btnSinhVien);
            this.pnlMenu.Controls.Add(this.btnTrangChu);
            this.pnlMenu.Controls.Add(this.lblLogo);
            this.pnlMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlMenu.Location = new System.Drawing.Point(0, 30);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.Size = new System.Drawing.Size(220, 611);
            this.pnlMenu.TabIndex = 3;
            // 
            // btnGiamSatThi
            // 
            this.btnGiamSatThi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGiamSatThi.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGiamSatThi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGiamSatThi.Location = new System.Drawing.Point(6, 488);
            this.btnGiamSatThi.Name = "btnGiamSatThi";
            this.btnGiamSatThi.Size = new System.Drawing.Size(210, 48);
            this.btnGiamSatThi.TabIndex = 9;
            this.btnGiamSatThi.Text = "👁️Giám sát thi";
            this.btnGiamSatThi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGiamSatThi.UseVisualStyleBackColor = true;
            // 
            // btnDangXuat
            // 
            this.btnDangXuat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDangXuat.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangXuat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDangXuat.Location = new System.Drawing.Point(6, 542);
            this.btnDangXuat.Name = "btnDangXuat";
            this.btnDangXuat.Size = new System.Drawing.Size(210, 48);
            this.btnDangXuat.TabIndex = 8;
            this.btnDangXuat.Text = "↪ Đăng xuất";
            this.btnDangXuat.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDangXuat.UseVisualStyleBackColor = true;
            // 
            // btnKetQua
            // 
            this.btnKetQua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKetQua.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKetQua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnKetQua.Location = new System.Drawing.Point(7, 434);
            this.btnKetQua.Name = "btnKetQua";
            this.btnKetQua.Size = new System.Drawing.Size(210, 48);
            this.btnKetQua.TabIndex = 7;
            this.btnKetQua.Text = "📊 Xem kết quả";
            this.btnKetQua.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnKetQua.UseVisualStyleBackColor = true;
            // 
            // btnToChucThi
            // 
            this.btnToChucThi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnToChucThi.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnToChucThi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnToChucThi.Location = new System.Drawing.Point(6, 380);
            this.btnToChucThi.Name = "btnToChucThi";
            this.btnToChucThi.Size = new System.Drawing.Size(210, 48);
            this.btnToChucThi.TabIndex = 6;
            this.btnToChucThi.Text = "▶ Tổ chức thi";
            this.btnToChucThi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnToChucThi.UseVisualStyleBackColor = true;
            // 
            // btnTaoDe
            // 
            this.btnTaoDe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTaoDe.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTaoDe.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTaoDe.Location = new System.Drawing.Point(6, 326);
            this.btnTaoDe.Name = "btnTaoDe";
            this.btnTaoDe.Size = new System.Drawing.Size(210, 48);
            this.btnTaoDe.TabIndex = 5;
            this.btnTaoDe.Text = "📋 Tạo đề thi";
            this.btnTaoDe.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTaoDe.UseVisualStyleBackColor = true;
            // 
            // btnCauHoi
            // 
            this.btnCauHoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCauHoi.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCauHoi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCauHoi.Location = new System.Drawing.Point(6, 272);
            this.btnCauHoi.Name = "btnCauHoi";
            this.btnCauHoi.Size = new System.Drawing.Size(210, 48);
            this.btnCauHoi.TabIndex = 4;
            this.btnCauHoi.Text = "📝 Ngân hàng câu hỏi";
            this.btnCauHoi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCauHoi.UseVisualStyleBackColor = true;
            // 
            // btnMonHoc
            // 
            this.btnMonHoc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMonHoc.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMonHoc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMonHoc.Location = new System.Drawing.Point(7, 218);
            this.btnMonHoc.Name = "btnMonHoc";
            this.btnMonHoc.Size = new System.Drawing.Size(210, 48);
            this.btnMonHoc.TabIndex = 3;
            this.btnMonHoc.Text = "📚 Quản lý môn học";
            this.btnMonHoc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMonHoc.UseVisualStyleBackColor = true;
            // 
            // btnSinhVien
            // 
            this.btnSinhVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSinhVien.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSinhVien.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSinhVien.Location = new System.Drawing.Point(7, 164);
            this.btnSinhVien.Name = "btnSinhVien";
            this.btnSinhVien.Size = new System.Drawing.Size(210, 48);
            this.btnSinhVien.TabIndex = 2;
            this.btnSinhVien.Text = "👥 Quản lý sinh viên";
            this.btnSinhVien.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSinhVien.UseVisualStyleBackColor = true;
            // 
            // btnTrangChu
            // 
            this.btnTrangChu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTrangChu.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrangChu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTrangChu.Location = new System.Drawing.Point(6, 110);
            this.btnTrangChu.Name = "btnTrangChu";
            this.btnTrangChu.Size = new System.Drawing.Size(210, 48);
            this.btnTrangChu.TabIndex = 1;
            this.btnTrangChu.Text = "🏠 Trang chủ";
            this.btnTrangChu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTrangChu.UseVisualStyleBackColor = true;
            this.btnTrangChu.Click += new System.EventHandler(this.btnTrangChu_Click);
            // 
            // lblLogo
            // 
            this.lblLogo.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(40)))), ((int)(((byte)(100)))));
            this.lblLogo.Location = new System.Drawing.Point(6, 10);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.Size = new System.Drawing.Size(210, 65);
            this.lblLogo.TabIndex = 0;
            this.lblLogo.Text = "QUẢN LÝ THI TRẮC NGHIỆM";
            this.lblLogo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlHeader
            // 
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(235)))), ((int)(((byte)(245)))));
            this.pnlHeader.Controls.Add(this.lblMoTa);
            this.pnlHeader.Controls.Add(this.lblTieuDe);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(220, 30);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(1405, 110);
            this.pnlHeader.TabIndex = 4;
            // 
            // lblMoTa
            // 
            this.lblMoTa.AutoSize = true;
            this.lblMoTa.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMoTa.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(70)))), ((int)(((byte)(110)))));
            this.lblMoTa.Location = new System.Drawing.Point(250, 70);
            this.lblMoTa.Name = "lblMoTa";
            this.lblMoTa.Size = new System.Drawing.Size(325, 25);
            this.lblMoTa.TabIndex = 1;
            this.lblMoTa.Text = "Học tập thông minh – Kiểm tra dễ dàng";
            this.lblMoTa.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.AutoSize = true;
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(45)))), ((int)(((byte)(105)))));
            this.lblTieuDe.Location = new System.Drawing.Point(138, 10);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(550, 50);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "HỆ THỐNG THI TRẮC NGHIỆM";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlNoiDung
            // 
            this.pnlNoiDung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.pnlNoiDung.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlNoiDung.Location = new System.Drawing.Point(220, 140);
            this.pnlNoiDung.Name = "pnlNoiDung";
            this.pnlNoiDung.Size = new System.Drawing.Size(1405, 501);
            this.pnlNoiDung.TabIndex = 6;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(240)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(1625, 641);
            this.Controls.Add(this.pnlNoiDung);
            this.Controls.Add(this.pnlHeader);
            this.Controls.Add(this.pnlMenu);
            this.Controls.Add(this.menuStrip1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(40)))), ((int)(((byte)(85)))));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hệ thống thi trắc nghiệm";
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.pnlMenu.ResumeLayout(false);
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sinhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mônHọcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ngânHàngCâuHỏiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thiCửToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tạoĐềThiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tổChứcThiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giámSátThiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xemBáoCáoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thốngKêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Panel pnlMenu;
        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.Button btnTrangChu;
        private System.Windows.Forms.Button btnDangXuat;
        private System.Windows.Forms.Button btnKetQua;
        private System.Windows.Forms.Button btnToChucThi;
        private System.Windows.Forms.Button btnTaoDe;
        private System.Windows.Forms.Button btnCauHoi;
        private System.Windows.Forms.Button btnMonHoc;
        private System.Windows.Forms.Button btnSinhVien;
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblMoTa;
        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.Button btnGiamSatThi;
        private System.Windows.Forms.Panel pnlNoiDung;
    }
}

