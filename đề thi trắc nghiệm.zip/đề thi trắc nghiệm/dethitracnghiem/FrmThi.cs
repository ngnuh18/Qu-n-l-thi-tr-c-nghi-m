using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace dethitracnghiem
{
    public partial class FrmThi : Form
    {
        private List<CauHoi> danhSachCauHoi = new List<CauHoi>();
        private Dictionary<int, string> cauTraLoi = new Dictionary<int, string>();
        private int viTriHienTai = 0;
        private int tongSoGiay = 45 * 60; // 45 phút = 2700 giây
        private bool dangCapNhatUI = false;
        private string tenMonHienTai = "Môn thi trắc nghiệm";

        public FrmThi()
        {
            InitializeComponent();
        }

        private void FrmThi_Load(object sender, EventArgs e)
        {
            NapDanhSachDeVaoCombo();
        }

        public void NapDanhSachDeVaoCombo()
        {
            cboChonDe.SelectedIndexChanged -= cboChonDe_SelectedIndexChanged;
            cboChonDe.Items.Clear();

            // 1. Ưu tiên nạp danh sách đề thi đã tạo
            foreach (var dt in DataStore.DanhSachDeThi)
            {
                cboChonDe.Items.Add(new DeThiItem { MaDe = dt.MaDe, TenHienThi = dt.TenDe, DeThi = dt });
            }

            // 2. Nếu chưa tạo đề nhưng đã nạp câu hỏi
            if (cboChonDe.Items.Count == 0 && DataStore.DanhSachCauHoi.Count > 0)
            {
                var cacMon = DataStore.DanhSachCauHoi.Select(c => c.MaMon).Distinct().ToList();
                foreach (var maMon in cacMon)
                {
                    var mh = DataStore.DanhSachMonHoc.FirstOrDefault(m => m.MaMon.Equals(maMon, StringComparison.OrdinalIgnoreCase));
                    string tenMon = mh != null ? mh.TenMon : ("Môn " + maMon);
                    cboChonDe.Items.Add(new DeThiItem { MaDe = maMon, TenHienThi = string.Format("Đề {0} ({1} câu)", tenMon, DataStore.DanhSachCauHoi.Count(c => c.MaMon.Equals(maMon, StringComparison.OrdinalIgnoreCase))), DeThi = null });
                }
            }

            cboChonDe.SelectedIndexChanged += cboChonDe_SelectedIndexChanged;

            if (cboChonDe.Items.Count > 0)
            {
                cboChonDe.SelectedIndex = 0;
            }
            else
            {
                KhoiDongThi(new List<CauHoi>(), "Chưa có đề thi");
            }
        }

        private class DeThiItem
        {
            public string MaDe { get; set; }
            public string TenHienThi { get; set; }
            public DeThi DeThi { get; set; }
            public override string ToString() => TenHienThi;
        }

        private void cboChonDe_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeThiItem item = cboChonDe.SelectedItem as DeThiItem;
            if (item == null) return;

            if (item.DeThi != null)
            {
                KhoiDongThi(item.DeThi.DanhSachCauHoi, item.DeThi.TenMon, item.DeThi.ThoiGianPhut);
            }
            else
            {
                var chs = DataStore.DanhSachCauHoi.Where(c => c.MaMon.Equals(item.MaDe, StringComparison.OrdinalIgnoreCase)).ToList();
                var mh = DataStore.DanhSachMonHoc.FirstOrDefault(m => m.MaMon.Equals(item.MaDe, StringComparison.OrdinalIgnoreCase));
                KhoiDongThi(chs, mh != null ? mh.TenMon : item.TenHienThi, 45);
            }
        }

        private void KhoiDongThi(List<CauHoi> cauHois, string tenMon, int thoiGianPhut = 45)
        {
            tenMonHienTai = tenMon;
            danhSachCauHoi = new List<CauHoi>(cauHois);

            if (danhSachCauHoi.Count == 0)
            {
                timerDemNguoc.Stop();
                lblNoiDungCauHoi.Text = "Hệ thống hiện chưa có đề thi hoặc câu hỏi nào. Vui lòng liên hệ Quản trị viên để nạp đề thi!";
                rdoA.Visible = false;
                rdoB.Visible = false;
                rdoC.Visible = false;
                rdoD.Visible = false;
                btnTiepTheo.Enabled = false;
                btnTruoc.Enabled = false;
                btnNopBai.Enabled = false;
                lblTienDo.Text = "Câu: 0 / 0";
                lblDongHo.Text = "⏱ 00:00:00";
                return;
            }

            rdoA.Visible = true;
            rdoB.Visible = true;
            rdoC.Visible = true;
            rdoD.Visible = true;
            btnNopBai.Enabled = true;

            viTriHienTai = 0;
            cauTraLoi.Clear();

            tongSoGiay = thoiGianPhut * 60;
            CapNhatDongHo();
            timerDemNguoc.Start();

            HienThiCauHoi(viTriHienTai);
        }

        private void CapNhatDongHo()
        {
            TimeSpan ts = TimeSpan.FromSeconds(Math.Max(0, tongSoGiay));
            lblDongHo.Text = "⏱ " + ts.ToString(@"hh\:mm\:ss");
        }

        private void timerDemNguoc_Tick(object sender, EventArgs e)
        {
            if (tongSoGiay > 0)
            {
                tongSoGiay--;
                CapNhatDongHo();
            }
            else
            {
                timerDemNguoc.Stop();
                MessageBox.Show("Đã hết thời gian 45 phút! Hệ thống sẽ tự động nộp bài thi.", "Hết giờ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                NopBaiThi();
            }
        }

        private void HienThiCauHoi(int index)
        {
            if (index < 0 || index >= danhSachCauHoi.Count) return;

            dangCapNhatUI = true;
            CauHoi ch = danhSachCauHoi[index];

            lblTienDo.Text = string.Format("Câu: {0} / {1}", index + 1, danhSachCauHoi.Count);
            lblNoiDungCauHoi.Text = string.Format("Câu {0}: {1}", index + 1, ch.NoiDung);

            rdoA.Text = "A. " + ch.DapAnA;
            rdoB.Text = "B. " + ch.DapAnB;
            rdoC.Text = "C. " + ch.DapAnC;
            rdoD.Text = "D. " + ch.DapAnD;

            rdoA.Checked = false;
            rdoB.Checked = false;
            rdoC.Checked = false;
            rdoD.Checked = false;

            if (cauTraLoi.ContainsKey(index))
            {
                string chon = cauTraLoi[index];
                if (chon == "A") rdoA.Checked = true;
                else if (chon == "B") rdoB.Checked = true;
                else if (chon == "C") rdoC.Checked = true;
                else if (chon == "D") rdoD.Checked = true;
            }

            btnTruoc.Enabled = (index > 0);
            if (index == danhSachCauHoi.Count - 1)
            {
                btnTiepTheo.Text = "Hoàn thành ➔";
            }
            else
            {
                btnTiepTheo.Text = "Tiếp theo ➔";
            }

            dangCapNhatUI = false;
        }

        private void rdo_CheckedChanged(object sender, EventArgs e)
        {
            if (dangCapNhatUI) return;

            RadioButton rdo = sender as RadioButton;
            if (rdo != null && rdo.Checked)
            {
                string ans = "";
                if (rdo == rdoA) ans = "A";
                else if (rdo == rdoB) ans = "B";
                else if (rdo == rdoC) ans = "C";
                else if (rdo == rdoD) ans = "D";

                cauTraLoi[viTriHienTai] = ans;
            }
        }

        private void btnTruoc_Click(object sender, EventArgs e)
        {
            if (viTriHienTai > 0)
            {
                viTriHienTai--;
                HienThiCauHoi(viTriHienTai);
            }
        }

        private void btnTiepTheo_Click(object sender, EventArgs e)
        {
            if (viTriHienTai < danhSachCauHoi.Count - 1)
            {
                viTriHienTai++;
                HienThiCauHoi(viTriHienTai);
            }
            else
            {
                // Câu cuối cùng -> hỏi nộp bài
                btnNopBai_Click(sender, e);
            }
        }

        private void btnNopBai_Click(object sender, EventArgs e)
        {
            int soCauDaLam = cauTraLoi.Count;
            int tongSo = danhSachCauHoi.Count;

            string thongBao = string.Format("Bạn đã trả lời {0}/{1} câu hỏi.\nBạn có chắc chắn muốn nộp bài thi không?", soCauDaLam, tongSo);
            DialogResult result = MessageBox.Show(thongBao, "Xác nhận nộp bài", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                timerDemNguoc.Stop();
                NopBaiThi();
            }
        }

        private void NopBaiThi()
        {
            int soCauDung = 0;
            int tongSo = danhSachCauHoi.Count;

            string mssvKq = !string.IsNullOrEmpty(DataStore.MSSVHienTai) ? DataStore.MSSVHienTai : (DataStore.NguoiDungHienTai.Equals("admin", StringComparison.OrdinalIgnoreCase) ? "ADMIN" : DataStore.NguoiDungHienTai);
            string hoTenKq = !string.IsNullOrEmpty(DataStore.HoTenHienTai) ? DataStore.HoTenHienTai : "Sinh viên";

            KetQuaThi kq = new KetQuaThi
            {
                MSSV = mssvKq,
                HoTen = hoTenKq,
                TenMon = !string.IsNullOrEmpty(tenMonHienTai) ? tenMonHienTai : "Bài thi trắc nghiệm",
                ThoiGian = DateTime.Now,
                TongSoCau = tongSo
            };

            for (int i = 0; i < tongSo; i++)
            {
                CauHoi ch = danhSachCauHoi[i];
                string daChon = cauTraLoi.ContainsKey(i) ? cauTraLoi[i] : "";

                bool dung = string.Equals(daChon, ch.DapAnDung, StringComparison.OrdinalIgnoreCase);
                if (dung) soCauDung++;

                kq.ChiTiet.Add(new ChiTietCauTraLoi
                {
                    CauHoi = ch,
                    DapAnChon = daChon,
                    DapAnDung = ch.DapAnDung
                });
            }

            kq.SoCauDung = soCauDung;
            kq.Diem = Math.Round((double)soCauDung / tongSo * 10.0, 1);

            if (kq.Diem >= 9.0) kq.XepLoai = "Xuất sắc";
            else if (kq.Diem >= 8.0) kq.XepLoai = "Giỏi";
            else if (kq.Diem >= 6.5) kq.XepLoai = "Khá";
            else if (kq.Diem >= 5.0) kq.XepLoai = "Trung bình";
            else kq.XepLoai = "Yếu";

            DataStore.DanhSachKetQua.Add(kq);
            DataStore.KetQuaMoiNhat = kq;

            // Cập nhật số đề đã thực hiện của sinh viên
            var sv = DataStore.DanhSachSinhVien.FirstOrDefault(s => s.HoTen == kq.HoTen || s.MSSV == kq.MSSV);
            if (sv != null)
            {
                sv.SoDe++;
            }
            DataStore.NotifyDataChanged();

            MessageBox.Show(
                string.Format("Chúc mừng bạn đã hoàn thành bài thi!\nĐiểm số: {0:0.0}\nXếp loại: {1}\nSố câu đúng: {2}/{3}",
                    kq.Diem, kq.XepLoai, kq.SoCauDung, kq.TongSoCau),
                "Kết quả bài thi",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );

            // Chuyển sang giao diện FrmKetQua trên FrmMain nếu có
            FrmMain main = this.TopLevelControl as FrmMain;
            if (main == null)
            {
                main = Application.OpenForms.OfType<FrmMain>().FirstOrDefault();
            }

            if (main != null)
            {
                main.MoFormCon(new FrmKetQua(kq));
            }
        }
    }
}
