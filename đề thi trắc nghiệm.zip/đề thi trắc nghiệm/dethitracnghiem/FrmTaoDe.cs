using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace dethitracnghiem
{
    public partial class FrmTaoDe : Form
    {
        private List<CauHoi> danhSachCauHoiMon = new List<CauHoi>();

        public FrmTaoDe()
        {
            InitializeComponent();
        }

        private void FrmTaoDe_Load(object sender, EventArgs e)
        {
            NapMonHoc();
        }

        private void NapMonHoc()
        {
            cboMonHoc.Items.Clear();
            foreach (var mh in DataStore.DanhSachMonHoc)
            {
                cboMonHoc.Items.Add(new MonHocItem { MaMon = mh.MaMon, TenMon = mh.TenMon });
            }

            if (cboMonHoc.Items.Count > 0)
            {
                cboMonHoc.SelectedIndex = 0;
            }
        }

        private class MonHocItem
        {
            public string MaMon { get; set; }
            public string TenMon { get; set; }
            public override string ToString() => TenMon;
        }

        private void cboMonHoc_SelectedIndexChanged(object sender, EventArgs e)
        {
            NapDanhSachCauHoiTheoMon();
        }

        private void NapDanhSachCauHoiTheoMon()
        {
            MonHocItem item = cboMonHoc.SelectedItem as MonHocItem;
            if (item == null) return;

            danhSachCauHoiMon = DataStore.DanhSachCauHoi.Where(c => c.MaMon == item.MaMon).ToList();
            clbDanhSachCauHoi.Items.Clear();

            int index = 1;
            foreach (var ch in danhSachCauHoiMon)
            {
                clbDanhSachCauHoi.Items.Add(string.Format("Câu {0}: {1}", index++, ch.NoiDung));
            }

            // Tự động chọn theo số câu hỏi
            btnChonTatCa_Click(null, null);
        }

        private void btnChonTatCa_Click(object sender, EventArgs e)
        {
            int soCauCanChon = (int)nudSoCau.Value;
            for (int i = 0; i < clbDanhSachCauHoi.Items.Count; i++)
            {
                clbDanhSachCauHoi.SetItemChecked(i, i < soCauCanChon);
            }
        }

        // Tải file câu hỏi từ máy tính vào để tạo đề
        private void btnTaiFile_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Title = "Chọn file câu hỏi / Excel từ máy tính để thêm vào đề thi";
                ofd.Filter = "Tất cả định dạng hỗ trợ (*.xlsx;*.xls;*.csv;*.txt)|*.xlsx;*.xls;*.csv;*.txt|File Excel (*.xlsx;*.xls)|*.xlsx;*.xls|File Text (*.txt)|*.txt|File CSV (*.csv)|*.csv|Tất cả tập tin (*.*)|*.*";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        MonHocItem item = cboMonHoc.SelectedItem as MonHocItem;
                        string maMon = item != null ? item.MaMon : (DataStore.DanhSachMonHoc.Count > 0 ? DataStore.DanhSachMonHoc[0].MaMon : "");

                        int dem = DataStore.DocCauHoiTuFile(ofd.FileName, maMon);
                        NapMonHoc();
                        NapDanhSachCauHoiTheoMon();
                        MessageBox.Show(string.Format("Đã tải thành công {0} câu hỏi từ máy tính!", dem), "Tải file thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi khi đọc file câu hỏi: " + ex.Message, "Lỗi tải file", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnNhapThuCong_Click(object sender, EventArgs e)
        {
            FrmMain main = this.TopLevelControl as FrmMain;
            if (main == null)
            {
                main = Application.OpenForms.OfType<FrmMain>().FirstOrDefault();
            }

            if (main != null)
            {
                main.MoFormCon(new FrmNhapCauHoi());
            }
        }

        private void btnTaoDeThi_Click(object sender, EventArgs e)
        {
            MonHocItem item = cboMonHoc.SelectedItem as MonHocItem;
            if (item == null)
            {
                MessageBox.Show("Vui lòng chọn môn học!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            List<CauHoi> cauHoiDaChon = new List<CauHoi>();
            for (int i = 0; i < clbDanhSachCauHoi.Items.Count; i++)
            {
                if (clbDanhSachCauHoi.GetItemChecked(i) && i < danhSachCauHoiMon.Count)
                {
                    cauHoiDaChon.Add(danhSachCauHoiMon[i]);
                }
            }

            if (cauHoiDaChon.Count == 0)
            {
                MessageBox.Show("Vui lòng tích chọn ít nhất 1 câu hỏi vào đề thi!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int soCau = cauHoiDaChon.Count;
            int thoiGian = (int)nudThoiGian.Value;
            string maDe = "DT" + (DataStore.DanhSachDeThi.Count + 1).ToString("D2");
            string tenDe = string.Format("Đề thi {0} - Mã {1}", item.TenMon, maDe);

            DeThi deThiMoi = new DeThi
            {
                MaDe = maDe,
                TenDe = tenDe,
                MaMon = item.MaMon,
                TenMon = item.TenMon,
                SoCau = soCau,
                ThoiGianPhut = thoiGian,
                DanhSachCauHoi = cauHoiDaChon
            };

            DataStore.DanhSachDeThi.Add(deThiMoi);
            DataStore.NotifyDataChanged();

            MessageBox.Show(
                string.Format("Đã tạo đề thi thành công!\nMã đề: {0}\nMôn: {1}\nSố câu: {2}\nThời gian làm bài: {3} phút",
                    maDe, item.TenMon, soCau, thoiGian),
                "Tạo đề thi thành công",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }
    }
}
