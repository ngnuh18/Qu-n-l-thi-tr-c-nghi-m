using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace dethitracnghiem
{
    public static class ExcelHelper
    {
        public static List<List<string>> DocTatCaCacDong(string filePath)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException("Không tìm thấy file: " + filePath);

            string ext = Path.GetExtension(filePath).ToLowerInvariant();
            if (ext == ".xlsx")
            {
                return DocFileXlsx(filePath);
            }
            else if (ext == ".xls")
            {
                return DocFileXls(filePath);
            }
            else
            {
                return DocFileTextCsv(filePath);
            }
        }

        private static List<List<string>> DocFileXlsx(string filePath)
        {
            var rows = new List<List<string>>();

            using (var archive = ZipFile.OpenRead(filePath))
            {
                // 1. Đọc Shared Strings nếu có
                var sharedStrings = new List<string>();
                var sstEntry = archive.GetEntry("xl/sharedStrings.xml");
                if (sstEntry != null)
                {
                    using (var stream = sstEntry.Open())
                    {
                        var sstDoc = XDocument.Load(stream);
                        foreach (var si in sstDoc.Descendants().Where(e => e.Name.LocalName == "si"))
                        {
                            var textNodes = si.Descendants().Where(e => e.Name.LocalName == "t").Select(t => t.Value);
                            sharedStrings.Add(string.Concat(textNodes));
                        }
                    }
                }

                // 2. Tìm worksheet đầu tiên
                ZipArchiveEntry sheetEntry = archive.GetEntry("xl/worksheets/sheet1.xml");
                if (sheetEntry == null)
                {
                    sheetEntry = archive.Entries.FirstOrDefault(e =>
                        e.FullName.StartsWith("xl/worksheets/sheet", StringComparison.OrdinalIgnoreCase) &&
                        e.FullName.EndsWith(".xml", StringComparison.OrdinalIgnoreCase));
                }

                if (sheetEntry == null)
                    throw new Exception("Không tìm thấy Sheet dữ liệu trong file Excel!");

                // 3. Đọc dữ liệu các dòng
                using (var stream = sheetEntry.Open())
                {
                    var sheetDoc = XDocument.Load(stream);
                    var rowElements = sheetDoc.Descendants().Where(e => e.Name.LocalName == "row");

                    foreach (var rowElem in rowElements)
                    {
                        var rowValues = new List<string>();
                        var cellElements = rowElem.Elements().Where(e => e.Name.LocalName == "c").ToList();

                        foreach (var c in cellElements)
                        {
                            string cellRef = c.Attribute("r")?.Value ?? "";
                            int colIndex = CellRefToColIndex(cellRef);
                            string val = LayGiaTriO(c, sharedStrings);

                            if (colIndex >= 0)
                            {
                                while (rowValues.Count < colIndex)
                                    rowValues.Add("");

                                if (colIndex < rowValues.Count)
                                    rowValues[colIndex] = val;
                                else
                                    rowValues.Add(val);
                            }
                            else
                            {
                                rowValues.Add(val);
                            }
                        }

                        // Chỉ thêm dòng nếu có ít nhất một ô có dữ liệu
                        if (rowValues.Any(v => !string.IsNullOrWhiteSpace(v)))
                        {
                            rows.Add(rowValues);
                        }
                    }
                }
            }

            return rows;
        }

        private static string LayGiaTriO(XElement c, List<string> sharedStrings)
        {
            string t = c.Attribute("t")?.Value ?? "";
            var vElem = c.Elements().FirstOrDefault(e => e.Name.LocalName == "v");
            string rawVal = vElem?.Value ?? "";

            if (t == "s") // Shared string
            {
                if (int.TryParse(rawVal, out int idx) && idx >= 0 && idx < sharedStrings.Count)
                    return sharedStrings[idx];
                return rawVal;
            }
            else if (t == "inlineStr")
            {
                var tElem = c.Descendants().FirstOrDefault(e => e.Name.LocalName == "t");
                return tElem != null ? tElem.Value : rawVal;
            }
            else if (t == "str")
            {
                return rawVal;
            }
            else if (t == "b")
            {
                return rawVal == "1" ? "true" : "false";
            }
            return rawVal;
        }

        private static int CellRefToColIndex(string cellRef)
        {
            if (string.IsNullOrEmpty(cellRef)) return -1;
            int col = 0;
            for (int i = 0; i < cellRef.Length; i++)
            {
                char ch = cellRef[i];
                if (ch >= 'A' && ch <= 'Z')
                    col = col * 26 + (ch - 'A' + 1);
                else if (ch >= 'a' && ch <= 'z')
                    col = col * 26 + (ch - 'a' + 1);
                else
                    break;
            }
            return col - 1; // 0-based
        }

        private static List<List<string>> DocFileXls(string filePath)
        {
            // Kiểm tra nếu là HTML hoặc XML Spreadsheet được lưu với đuôi .xls
            try
            {
                string text = File.ReadAllText(filePath, Encoding.UTF8);
                if (text.Contains("<Workbook") || text.Contains("<table") || text.Contains("<html"))
                {
                    return DocFileHtmlOrXml(text);
                }
            }
            catch { }

            // Thử đọc qua OleDb nếu hệ thống có cài đặt Microsoft.ACE.OLEDB
            try
            {
                string connStr = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Excel 8.0;HDR=NO;IMEX=1\";", filePath);
                using (var conn = new System.Data.OleDb.OleDbConnection(connStr))
                {
                    conn.Open();
                    var dtSchema = conn.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Tables, null);
                    if (dtSchema != null && dtSchema.Rows.Count > 0)
                    {
                        string sheetName = dtSchema.Rows[0]["TABLE_NAME"].ToString();
                        using (var cmd = new System.Data.OleDb.OleDbCommand("SELECT * FROM [" + sheetName + "]", conn))
                        using (var adapter = new System.Data.OleDb.OleDbDataAdapter(cmd))
                        {
                            var dt = new System.Data.DataTable();
                            adapter.Fill(dt);
                            var rows = new List<List<string>>();
                            foreach (System.Data.DataRow r in dt.Rows)
                            {
                                var rList = new List<string>();
                                foreach (var item in r.ItemArray)
                                {
                                    rList.Add(item != null ? item.ToString().Trim() : "");
                                }
                                if (rList.Any(x => !string.IsNullOrWhiteSpace(x)))
                                    rows.Add(rList);
                            }
                            return rows;
                        }
                    }
                }
            }
            catch { }

            // Fallback đọc dạng text/csv
            return DocFileTextCsv(filePath);
        }

        private static List<List<string>> DocFileHtmlOrXml(string text)
        {
            var rows = new List<List<string>>();
            var lines = text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            List<string> currentRow = null;

            foreach (var line in lines)
            {
                string trimmed = line.Trim();
                if (trimmed.StartsWith("<tr", StringComparison.OrdinalIgnoreCase) || trimmed.StartsWith("<Row", StringComparison.OrdinalIgnoreCase))
                {
                    if (currentRow != null && currentRow.Any(c => !string.IsNullOrWhiteSpace(c)))
                        rows.Add(currentRow);
                    currentRow = new List<string>();
                }
                else if (currentRow != null && (trimmed.StartsWith("<td", StringComparison.OrdinalIgnoreCase) || trimmed.StartsWith("<Cell", StringComparison.OrdinalIgnoreCase)))
                {
                    int start = trimmed.IndexOf('>') + 1;
                    int end = trimmed.LastIndexOf('<');
                    if (start > 0 && end > start)
                    {
                        string val = System.Text.RegularExpressions.Regex.Replace(trimmed.Substring(start, end - start), "<.*?>", "").Trim();
                        currentRow.Add(System.Net.WebUtility.HtmlDecode(val));
                    }
                }
            }
            if (currentRow != null && currentRow.Any(c => !string.IsNullOrWhiteSpace(c)))
                rows.Add(currentRow);

            return rows;
        }

        private static List<List<string>> DocFileTextCsv(string filePath)
        {
            var rows = new List<List<string>>();
            Encoding encoding = NhanDienEncoding(filePath);
            var lines = File.ReadAllLines(filePath, encoding);

            foreach (var line in lines)
            {
                if (string.IsNullOrWhiteSpace(line) || line.StartsWith("#"))
                    continue;

                var parts = TachCotCsv(line);
                if (parts.Any(p => !string.IsNullOrWhiteSpace(p)))
                {
                    rows.Add(parts);
                }
            }
            return rows;
        }

        public static List<string> TachCotCsv(string line)
        {
            var result = new List<string>();
            char separator = ',';
            if (line.Contains('\t')) separator = '\t';
            else if (line.Contains(';')) separator = ';';
            else if (line.Contains('|')) separator = '|';

            bool inQuotes = false;
            var sb = new StringBuilder();

            for (int i = 0; i < line.Length; i++)
            {
                char ch = line[i];
                if (ch == '"')
                {
                    if (inQuotes && i + 1 < line.Length && line[i + 1] == '"')
                    {
                        sb.Append('"');
                        i++;
                    }
                    else
                    {
                        inQuotes = !inQuotes;
                    }
                }
                else if (ch == separator && !inQuotes)
                {
                    result.Add(sb.ToString().Trim());
                    sb.Clear();
                }
                else
                {
                    sb.Append(ch);
                }
            }
            result.Add(sb.ToString().Trim());
            return result;
        }

        private static Encoding NhanDienEncoding(string filePath)
        {
            byte[] bom = new byte[4];
            using (var file = new FileStream(filePath, FileMode.Open, FileAccess.Read))
            {
                file.Read(bom, 0, 4);
            }

            if (bom[0] == 0xef && bom[1] == 0xbb && bom[2] == 0xbf) return Encoding.UTF8;
            if (bom[0] == 0xff && bom[1] == 0xfe) return Encoding.Unicode;
            if (bom[0] == 0xfe && bom[1] == 0xff) return Encoding.BigEndianUnicode;
            if (bom[0] == 0 && bom[1] == 0 && bom[2] == 0xfe && bom[3] == 0xff) return Encoding.UTF32;

            return Encoding.UTF8;
        }
    }
}
