using System;
using System.Drawing;
using System.Windows.Forms;

namespace dethitracnghiem
{
    public partial class FrmMain : Form
    {
        private string vaiTro;
        private Form formHienTai;
        private FrmDangNhap formDangNhap;

        public FrmMain()
        {
            InitializeComponent();

            // Gắn sự kiện các nút trên thanh menu bên trái
            btnTrangChu.Click -= btnTrangChu_Click;
            btnTrangChu.Click += btnTrangChu_Click;

            btnSinhVien.Click -= btnSinhVien_Click;
            btnSinhVien.Click += btnSinhVien_Click;

            btnMonHoc.Click -= btnMonHoc_Click;
            btnMonHoc.Click += btnMonHoc_Click;

            btnCauHoi.Click -= btnCauHoi_Click;
            btnCauHoi.Click += btnCauHoi_Click;

            btnTaoDe.Click -= btnTaoDe_Click;
            btnTaoDe.Click += btnTaoDe_Click;

            btnToChucThi.Click -= btnToChucThi_Click;
            btnToChucThi.Click += btnToChucThi_Click;

            btnKetQua.Click -= btnKetQua_Click;
            btnKetQua.Click += btnKetQua_Click;

            btnGiamSatThi.Click -= btnGiamSatThi_Click;
            btnGiamSatThi.Click += btnGiamSatThi_Click;

            btnDangXuat.Click -= btnDangXuat_Click;
            btnDangXuat.Click += btnDangXuat_Click;

            // Gắn sự kiện MenuStrip
            sinhViênToolStripMenuItem.Click += btnSinhVien_Click;
            mônHọcToolStripMenuItem.Click += btnMonHoc_Click;
            ngânHàngCâuHỏiToolStripMenuItem.Click += btnCauHoi_Click;
            tạoĐềThiToolStripMenuItem.Click += btnTaoDe_Click;
            tổChứcThiToolStripMenuItem.Click += btnToChucThi_Click;
            giámSátThiToolStripMenuItem.Click += btnGiamSatThi_Click;
            xemBáoCáoToolStripMenuItem.Click += btnKetQua_Click;
            thốngKêToolStripMenuItem.Click += btnKetQua_Click;
            đăngXuấtToolStripMenuItem.Click += btnDangXuat_Click;
            thoátToolStripMenuItem.Click += (s, e) => Application.Exit();
        }

        // Nhận vai trò và Form đăng nhập
        public FrmMain(string role, FrmDangNhap login) : this()
        {
            vaiTro = role;
            formDangNhap = login;

            PhanQuyen();

            this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Normal;
            this.ShowInTaskbar = true;
        }

        // Mở Form con trong phần trống của FrmMain (pnlNoiDung)
        public void MoFormCon(Form frm)
        {
            try
            {
                if (formHienTai != null)
                {
                    pnlNoiDung.Controls.Remove(formHienTai);
                    formHienTai.Close();
                    formHienTai.Dispose();
                    formHienTai = null;
                }

                frm.TopLevel = false;
                frm.FormBorderStyle = FormBorderStyle.None;
                frm.Dock = DockStyle.Fill;

                pnlNoiDung.Controls.Clear();
                pnlNoiDung.Controls.Add(frm);

                formHienTai = frm;

                frm.Show();
                frm.BringToFront();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể mở Form con: " + ex.Message,
                    "Thông báo lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        // Yêu cầu: "Khi không phải role thì vẫn hiện các button chứ không biến mất, nhưng khi bấm vào thì hiện bạn không có đặc quyền"
        private void PhanQuyen()
        {
            btnTrangChu.Visible = true;
            btnSinhVien.Visible = true;
            btnMonHoc.Visible = true;
            btnCauHoi.Visible = true;
            btnTaoDe.Visible = true;
            btnToChucThi.Visible = true;
            btnKetQua.Visible = true;
            btnGiamSatThi.Visible = true;
            btnDangXuat.Visible = true;

            lblMoTa.Text = string.Format("Xin chào: {0} ({1}) | Học tập thông minh – Kiểm tra dễ dàng",
                DataStore.HoTenHienTai, vaiTro);
        }

        private bool KiemTraQuyen(string chucNang)
        {
            // Quyền của sinh viên: chỉ được quyền hoạt động ở trang chủ, xem môn học, ngân hàng câu hỏi, tổ chức thi và xem kết quả, quản lý sinh viên
            if (vaiTro == "Sinh viên")
            {
                if (chucNang == "TrangChu" ||
                    chucNang == "SinhVien" ||
                    chucNang == "MonHoc" ||
                    chucNang == "CauHoi" ||
                    chucNang == "ToChucThi" ||
                    chucNang == "KetQua")
                {
                    return true;
                }
                return false;
            }

            // Quyền của quản trị viên: có đầy đủ mọi đặc quyền
            if (vaiTro == "Quản trị viên")
            {
                return true;
            }

            return false;
        }

        private void XuLyChucNang(string chucNang)
        {
            if (!KiemTraQuyen(chucNang))
            {
                MessageBox.Show(
                    "bạn không có đặc quyền",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                return;
            }

            // Mở form tương ứng trong phần trống của FrmMain
            switch (chucNang)
            {
                case "TrangChu":
                    MoFormCon(new FrmTrangChu(vaiTro));
                    break;
                case "SinhVien":
                    MoFormCon(new FrmQuanLySinhVien(vaiTro));
                    break;
                case "MonHoc":
                    MoFormCon(new FrmMonHoc(vaiTro));
                    break;
                case "CauHoi":
                    MoFormCon(new FrmNhapCauHoi(vaiTro));
                    break;
                case "TaoDe":
                    MoFormCon(new FrmTaoDe());
                    break;
                case "ToChucThi":
                    MoFormCon(new FrmThi());
                    break;
                case "KetQua":
                    MoFormCon(new FrmKetQua());
                    break;
                case "GiamSatThi":
                    MoFormCon(new FrmGiamSatThi());
                    break;
            }
        }

        private void btnTrangChu_Click(object sender, EventArgs e)
        {
            XuLyChucNang("TrangChu");
        }

        private void btnSinhVien_Click(object sender, EventArgs e)
        {
            XuLyChucNang("SinhVien");
        }

        private void btnMonHoc_Click(object sender, EventArgs e)
        {
            XuLyChucNang("MonHoc");
        }

        private void btnCauHoi_Click(object sender, EventArgs e)
        {
            XuLyChucNang("CauHoi");
        }

        private void btnTaoDe_Click(object sender, EventArgs e)
        {
            XuLyChucNang("TaoDe");
        }

        private void btnToChucThi_Click(object sender, EventArgs e)
        {
            XuLyChucNang("ToChucThi");
        }

        private void btnKetQua_Click(object sender, EventArgs e)
        {
            XuLyChucNang("KetQua");
        }

        private void btnGiamSatThi_Click(object sender, EventArgs e)
        {
            XuLyChucNang("GiamSatThi");
        }

        // Khi FrmMain được mở
        private void FrmMain_Load(object sender, EventArgs e)
        {
            try
            {
                MoFormCon(new FrmTrangChu(vaiTro));
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Lỗi khi mở trang chủ: " + ex.Message,
                    "Thông báo lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        // Nút Đăng xuất
        private void btnDangXuat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có chắc chắn muốn đăng xuất?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                if (formDangNhap != null)
                {
                    formDangNhap.Show();
                }
                this.Close();
            }
        }

        // Khi đóng FrmMain bằng nút X
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            base.OnFormClosed(e);

            if (formDangNhap != null && !formDangNhap.Visible)
            {
                Application.Exit();
            }
        }
    }
}
