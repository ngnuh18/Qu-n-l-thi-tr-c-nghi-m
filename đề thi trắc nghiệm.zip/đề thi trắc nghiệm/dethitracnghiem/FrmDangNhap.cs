using System;
using System.Linq;
using System.Windows.Forms;

namespace dethitracnghiem
{
    public partial class FrmDangNhap : Form
    {
        public FrmDangNhap()
        {
            InitializeComponent();

            this.btnThoat.Click -= btnThoat_Click;
            this.btnThoat.Click += btnThoat_Click;
        }

        private void FrmDangNhap_Load(object sender, EventArgs e)
        {
            txtMatKhau.PasswordChar = '*';
            this.AcceptButton = btnDangNhap;

            // Để trống toàn bộ thông tin đăng nhập theo yêu cầu người dùng
            txtTenDangNhap.Clear();
            txtMatKhau.Clear();
            rdoSinhVien.Checked = false;
            rdoQuanTriVien.Checked = false;

            txtTenDangNhap.Focus();
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            string tenDangNhap = txtTenDangNhap.Text.Trim();
            string matKhau = txtMatKhau.Text;

            // 1. Kiểm tra nhập liệu
            if (string.IsNullOrEmpty(tenDangNhap) || string.IsNullOrEmpty(matKhau))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 2. Kiểm tra chọn vai trò
            if (!rdoSinhVien.Checked && !rdoQuanTriVien.Checked)
            {
                MessageBox.Show("Vui lòng chọn vai trò đăng nhập (Sinh viên hoặc Quản trị viên)!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string vaiTro = "";

            // 3. Đăng nhập với vai trò Sinh viên
            if (rdoSinhVien.Checked)
            {
                // Nhập admin mà chọn sinh viên thì báo lỗi
                if (tenDangNhap.Equals("admin", StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("Tài khoản 'admin' không thể đăng nhập với vai trò Sinh viên!", "Lỗi đăng nhập", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Tìm tài khoản sinh viên trong hệ thống (theo Tên đăng nhập hoặc MSSV)
                var tk = DataStore.DanhSachTaiKhoan.FirstOrDefault(t =>
                    (t.TenDangNhap.Equals(tenDangNhap, StringComparison.OrdinalIgnoreCase) ||
                     t.MSSV.Equals(tenDangNhap, StringComparison.OrdinalIgnoreCase)) &&
                    t.VaiTro == "Sinh viên"
                );

                if (tk == null)
                {
                    MessageBox.Show(
                        "Tài khoản sinh viên không tồn tại trong hệ thống!\nBạn vui lòng bấm nút 'Đăng ký tài khoản Sinh viên' hoặc nạp danh sách sinh viên từ file.",
                        "Lỗi đăng nhập",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    return;
                }

                if (tk.MatKhau != matKhau)
                {
                    MessageBox.Show("Mật khẩu không chính xác!", "Lỗi đăng nhập", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMatKhau.Clear();
                    txtMatKhau.Focus();
                    return;
                }

                vaiTro = "Sinh viên";
                DataStore.NguoiDungHienTai = tk.TenDangNhap;
                DataStore.HoTenHienTai = tk.HoTen;
                DataStore.VaiTroHienTai = "Sinh viên";
                DataStore.MSSVHienTai = tk.MSSV;
                DataStore.LopHienTai = tk.Lop;
            }
            // 4. Đăng nhập với vai trò Quản trị viên
            else if (rdoQuanTriVien.Checked)
            {
                // Nhập tài khoản sinh viên mà chọn quản trị viên thì báo lỗi
                bool laTaiKhoanSinhVien = DataStore.DanhSachTaiKhoan.Any(t =>
                    (t.TenDangNhap.Equals(tenDangNhap, StringComparison.OrdinalIgnoreCase) ||
                     t.MSSV.Equals(tenDangNhap, StringComparison.OrdinalIgnoreCase)) &&
                    t.VaiTro == "Sinh viên"
                );

                if (laTaiKhoanSinhVien || tenDangNhap.Equals("sinhvien", StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("Tài khoản sinh viên không thể đăng nhập với vai trò Quản trị viên!", "Lỗi đăng nhập", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (tenDangNhap.Equals("admin", StringComparison.OrdinalIgnoreCase))
                {
                    var adminTk = DataStore.DanhSachTaiKhoan.FirstOrDefault(t => t.TenDangNhap.Equals("admin", StringComparison.OrdinalIgnoreCase));
                    string adminPass = adminTk != null ? adminTk.MatKhau : "123";

                    if (matKhau != adminPass)
                    {
                        MessageBox.Show("Mật khẩu quản trị viên không chính xác!", "Lỗi đăng nhập", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtMatKhau.Clear();
                        txtMatKhau.Focus();
                        return;
                    }

                    vaiTro = "Quản trị viên";
                    DataStore.NguoiDungHienTai = "admin";
                    DataStore.HoTenHienTai = adminTk != null ? adminTk.HoTen : "Quản trị viên hệ thống";
                    DataStore.VaiTroHienTai = "Quản trị viên";
                    DataStore.MSSVHienTai = "ADMIN";
                    DataStore.LopHienTai = "Ban quản trị";
                }
                else
                {
                    MessageBox.Show("Tên đăng nhập hoặc mật khẩu quản trị viên không đúng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMatKhau.Clear();
                    txtMatKhau.Focus();
                    return;
                }
            }

            try
            {
                FrmMain frm = new FrmMain(vaiTro, this);
                frm.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Lỗi khởi chạy hệ thống: " + ex.Message,
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        // Tự tạo tài khoản và mật khẩu cho sinh viên
        private void btnDangKy_Click(object sender, EventArgs e)
        {
            using (FrmDangKy frm = new FrmDangKy())
            {
                if (frm.ShowDialog(this) == DialogResult.OK)
                {
                    rdoSinhVien.Checked = true;
                    txtTenDangNhap.Text = frm.TenDangNhapMoi;
                    txtMatKhau.Text = frm.MatKhauMoi;
                    btnDangNhap.Focus();
                }
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có chắc chắn muốn thoát chương trình?",
                "Xác nhận thoát",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
