using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace dethitracnghiem
{
    public partial class FrmMonHoc : Form
    {
        private string vaiTro;

        public FrmMonHoc()
        {
            InitializeComponent();
            this.vaiTro = DataStore.VaiTroHienTai;
        }

        public FrmMonHoc(string role) : this()
        {
            this.vaiTro = role;
        }

        private void FrmMonHoc_Load(object sender, EventArgs e)
        {
            ApDungPhanQuyen();
            NapDanhSachMonHoc();
        }

        private void ApDungPhanQuyen()
        {
            if (vaiTro == "Sinh viên")
            {
                // Ẩn nút thêm, sửa, xóa, tải file
                btnThem.Visible = false;
                btnSua.Visible = false;
                btnXoa.Visible = false;
                btnTaiFile.Visible = false;
                btnLamMoi.Visible = false;

                // Chế độ chỉ đọc
                txtMaMon.ReadOnly = true;
                txtTenMon.ReadOnly = true;
                txtGhiChu.ReadOnly = true;
                numericUpDown1.Enabled = false;
            }
            else
            {
                // Quản trị viên: hiển thị đầy đủ
                btnThem.Visible = true;
                btnSua.Visible = true;
                btnXoa.Visible = true;
                btnTaiFile.Visible = true;
                btnLamMoi.Visible = true;

                txtMaMon.ReadOnly = false;
                txtTenMon.ReadOnly = false;
                txtGhiChu.ReadOnly = false;
                numericUpDown1.Enabled = true;
            }
        }

        private void NapDanhSachMonHoc()
        {
            tvMonHoc.BeginUpdate();
            tvMonHoc.Nodes.Clear();

            // TreeView chỉ hiển thị tên môn theo yêu cầu
            foreach (var mh in DataStore.DanhSachMonHoc)
            {
                TreeNode node = new TreeNode(mh.TenMon);
                node.Tag = mh;
                tvMonHoc.Nodes.Add(node);
            }

            tvMonHoc.EndUpdate();
            tvMonHoc.ExpandAll();

            if (tvMonHoc.Nodes.Count > 0)
            {
                tvMonHoc.SelectedNode = tvMonHoc.Nodes[0];
            }
        }

        // Khi người dùng bấm/chọn vào môn học trên treeview thì hiện thông tin ở bên phải
        private void tvMonHoc_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node == null || e.Node.Tag == null) return;

            MonHoc mh = e.Node.Tag as MonHoc;
            if (mh != null)
            {
                txtMaMon.Text = mh.MaMon;
                txtTenMon.Text = mh.TenMon;
                numericUpDown1.Value = Math.Max(numericUpDown1.Minimum, Math.Min(numericUpDown1.Maximum, mh.SoTinChi));
                txtGhiChu.Text = mh.GhiChu;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            string ma = txtMaMon.Text.Trim();
            string ten = txtTenMon.Text.Trim();
            int tinChi = (int)numericUpDown1.Value;
            string ghiChu = txtGhiChu.Text.Trim();

            if (string.IsNullOrEmpty(ma) || string.IsNullOrEmpty(ten))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ mã môn và tên môn!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (DataStore.DanhSachMonHoc.Any(m => m.MaMon.Equals(ma, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show("Mã môn học này đã tồn tại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MonHoc mh = new MonHoc(ma, ten, tinChi, ghiChu);
            DataStore.DanhSachMonHoc.Add(mh);
            DataStore.NotifyDataChanged();

            // Thêm vào treeview chỉ hiện tên môn
            TreeNode node = new TreeNode(mh.TenMon);
            node.Tag = mh;
            tvMonHoc.Nodes.Add(node);
            tvMonHoc.SelectedNode = node;

            MessageBox.Show("Đã thêm môn học thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (tvMonHoc.SelectedNode == null)
            {
                MessageBox.Show("Vui lòng chọn môn học cần sửa trên cây danh sách!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MonHoc mh = tvMonHoc.SelectedNode.Tag as MonHoc;
            if (mh == null) return;

            string ma = txtMaMon.Text.Trim();
            string ten = txtTenMon.Text.Trim();
            int tinChi = (int)numericUpDown1.Value;
            string ghiChu = txtGhiChu.Text.Trim();

            if (string.IsNullOrEmpty(ma) || string.IsNullOrEmpty(ten))
            {
                MessageBox.Show("Mã môn và tên môn không được để trống!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            mh.MaMon = ma;
            mh.TenMon = ten;
            mh.SoTinChi = tinChi;
            mh.GhiChu = ghiChu;

            // Cập nhật tên môn trên TreeView
            tvMonHoc.SelectedNode.Text = ten;
            DataStore.NotifyDataChanged();

            MessageBox.Show("Đã cập nhật môn học thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (tvMonHoc.SelectedNode == null)
            {
                MessageBox.Show("Vui lòng chọn môn học cần xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MonHoc mh = tvMonHoc.SelectedNode.Tag as MonHoc;
            if (mh == null) return;

            DialogResult dr = MessageBox.Show(string.Format("Bạn có chắc chắn muốn xóa môn học \"{0}\"?", mh.TenMon), "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                DataStore.DanhSachMonHoc.Remove(mh);
                tvMonHoc.Nodes.Remove(tvMonHoc.SelectedNode);
                DataStore.NotifyDataChanged();

                btnLamMoi_Click(sender, e);
                MessageBox.Show("Đã xóa môn học thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Tải file từ máy chính vào
        private void btnTaiFile_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Title = "Chọn file Excel / Danh sách môn học";
                ofd.Filter = "Tất cả định dạng hỗ trợ (*.xlsx;*.xls;*.csv;*.txt)|*.xlsx;*.xls;*.csv;*.txt|File Excel (*.xlsx;*.xls)|*.xlsx;*.xls|File CSV (*.csv)|*.csv|File Text (*.txt)|*.txt|Tất cả tập tin (*.*)|*.*";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        int dem = DataStore.DocMonHocTuFile(ofd.FileName);
                        NapDanhSachMonHoc();
                        MessageBox.Show(string.Format("Đã tải thành công {0} môn học từ file!", dem), "Tải file thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi khi đọc file: " + ex.Message, "Lỗi tải file", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            txtMaMon.Clear();
            txtTenMon.Clear();
            txtGhiChu.Clear();
            numericUpDown1.Value = 3;
            txtMaMon.Focus();
        }
    }
}
